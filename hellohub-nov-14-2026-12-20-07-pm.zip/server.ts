import express from 'express';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface StoredUser {
  uid: string;
  username: string;
  password: string;
  photoURL: string;
  blockedUsers: string[];
  createdAt: string;
}

interface StoredProduct {
  id: string;
  name: string;
  price: string;
  currency: string;
  description: string;
  photoURL: string;
  userId: string;
  username: string;
  userPhoto: string;
  createdAt: string;
}

interface StoredMediaItem {
  src: string;
  mediaType: 'image' | 'video';
}

interface StoredMessage {
  id: string;
  threadKey: string;
  senderId: string;
  recipientId: string;
  text: string;
  media: string;
  mediaType: 'image' | 'video' | '';
  mediaItems?: StoredMediaItem[];
  timestamp: string;
  readBy: string[];
}

interface StoreData {
  users: StoredUser[];
  products: StoredProduct[];
  messages: StoredMessage[];
}

const DATA_DIR = path.resolve(__dirname, '.data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');

function getThreadKey(a: string, b: string): string {
  return [a, b].sort().join('__');
}

function createInitialStore(): StoreData {
  return {
    users: [],
    products: [],
    messages: [],
  };
}

function loadStore(): StoreData {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(raw) as StoreData;
      if (Array.isArray(parsed.users) && Array.isArray(parsed.products) && Array.isArray(parsed.messages)) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to load store.json, re-initializing:', err);
  }
  const initial = createInitialStore();
  saveStore(initial);
  return initial;
}

function saveStore(data: StoreData): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to persist store.json:', err);
  }
}

function toPublicUser(u: StoredUser) {
  return {
    uid: u.uid,
    username: u.username,
    photoURL: u.photoURL,
    blockedUsers: u.blockedUsers || [],
    createdAt: u.createdAt,
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '30mb' }));

  const store = loadStore();

  // Serve generated images reliably in both dev and production
  app.use('/src/assets/images', express.static(path.resolve(__dirname, 'src/assets/images')));

  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });
  const socketUsers = new Map<WebSocket, string>();

  httpServer.on('upgrade', (req, socket, head) => {
    if (req.url && req.url.startsWith('/ws-chat')) {
      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit('connection', ws, req);
      });
    }
  });

  wss.on('connection', (ws) => {
    ws.on('message', (raw) => {
      try {
        const payload = JSON.parse(raw.toString()) as { type?: string; userId?: string };
        if (payload.type === 'auth:identify' && typeof payload.userId === 'string') {
          socketUsers.set(ws, payload.userId);
        }
      } catch {
        // Ignore malformed client frames
      }
    });

    ws.on('close', () => {
      socketUsers.delete(ws);
    });
  });

  function broadcastAll(event: Record<string, unknown>) {
    const encoded = JSON.stringify(event);
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(encoded);
      }
    }
  }

  function broadcastToUsers(userIds: string[], event: Record<string, unknown>) {
    const targetSet = new Set(userIds);
    const encoded = JSON.stringify(event);
    for (const client of wss.clients) {
      if (client.readyState !== WebSocket.OPEN) continue;
      const uid = socketUsers.get(client);
      if (uid && targetSet.has(uid)) {
        client.send(encoded);
      }
    }
  }

  // Health & Firebase status check
  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      firebaseConfigured: false,
      realtimeTransport: 'websocket',
    });
  });

  // Register account
  app.post('/api/auth/register', (req, res) => {
    const { username, password, photoURL } = req.body as {
      username?: string;
      password?: string;
      photoURL?: string;
    };

    const trimmed = (username || '').trim();
    if (!photoURL) {
      res.status(400).json({ error: 'Please put your profile picture' });
      return;
    }
    if (trimmed.length < 2 || trimmed.length > 16) {
      res.status(400).json({ error: 'Username must be 2 to 16 characters.' });
      return;
    }
    if (!password || password.length < 2 || password.length > 16) {
      res.status(400).json({ error: 'Password must be 2 to 16 characters.' });
      return;
    }

    const exists = store.users.find(
      (u) => u.username.toLowerCase() === trimmed.toLowerCase()
    );
    if (exists) {
      res.status(409).json({ error: 'Username already exists. Tap Sign In instead.' });
      return;
    }

    const newUser: StoredUser = {
      uid: `user_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      username: trimmed,
      password,
      photoURL,
      blockedUsers: [],
      createdAt: new Date().toISOString(),
    };

    store.users.push(newUser);
    saveStore(store);

    const publicUser = toPublicUser(newUser);
    broadcastAll({ type: 'user:updated', user: publicUser });
    res.status(201).json({ user: publicUser });
  });

  // Sign in
  app.post('/api/auth/login', (req, res) => {
    const { username, password, photoURL } = req.body as {
      username?: string;
      password?: string;
      photoURL?: string;
    };

    const trimmed = (username || '').trim().toLowerCase();
    const found = store.users.find((u) => u.username.toLowerCase() === trimmed);

    if (!found || found.password !== password) {
      res.status(401).json({ error: 'Account not found or incorrect credentials!' });
      return;
    }

    if (photoURL) {
      found.photoURL = photoURL;
      for (const p of store.products) {
        if (p.userId === found.uid) {
          p.userPhoto = photoURL;
        }
      }
      saveStore(store);
    }

    const publicUser = toPublicUser(found);
    broadcastAll({ type: 'user:updated', user: publicUser });
    res.json({ user: publicUser });
  });

  // Get single user session refresh
  app.get('/api/users/:uid', (req, res) => {
    const found = store.users.find((u) => u.uid === req.params.uid);
    if (!found) {
      res.status(404).json({ error: 'User not found' });
      return;
    }
    res.json({ user: toPublicUser(found) });
  });

  // Public users directory
  app.get('/api/users', (_req, res) => {
    res.json({ users: store.users.map(toPublicUser) });
  });

  // Update profile / password
  app.put('/api/users/:uid', (req, res) => {
    const user = store.users.find((u) => u.uid === req.params.uid);
    if (!user) {
      res.status(404).json({ error: 'User not found' });
      return;
    }

    const { username, photoURL, oldPassword, newPassword } = req.body as {
      username?: string;
      photoURL?: string;
      oldPassword?: string;
      newPassword?: string;
    };

    const trimmed = (username || '').trim();
    if (trimmed.length < 2 || trimmed.length > 16) {
      res.status(400).json({ error: 'Username must be 2 to 16 characters.' });
      return;
    }

    const duplicate = store.users.find(
      (u) => u.uid !== user.uid && u.username.toLowerCase() === trimmed.toLowerCase()
    );
    if (duplicate) {
      res.status(409).json({ error: 'That username is already taken.' });
      return;
    }

    if (newPassword !== undefined && newPassword !== '') {
      if (oldPassword !== user.password) {
        res.status(400).json({ error: 'First password does not match current password!' });
        return;
      }
      if (newPassword.length < 2 || newPassword.length > 16) {
        res.status(400).json({ error: 'New password must be 2 to 16 characters.' });
        return;
      }
      user.password = newPassword;
    }

    user.username = trimmed;
    if (photoURL) {
      user.photoURL = photoURL;
    }

    for (const prod of store.products) {
      if (prod.userId === user.uid) {
        prod.username = user.username;
        prod.userPhoto = user.photoURL;
      }
    }

    saveStore(store);
    const publicUser = toPublicUser(user);
    broadcastAll({ type: 'user:updated', user: publicUser });
    broadcastAll({ type: 'products:sync', products: store.products });
    res.json({ user: publicUser });
  });

  // Delete account
  app.delete('/api/users/:uid', (req, res) => {
    const idx = store.users.findIndex((u) => u.uid === req.params.uid);
    if (idx === -1) {
      res.status(404).json({ error: 'User not found' });
      return;
    }
    const uid = store.users[idx].uid;
    store.users.splice(idx, 1);
    store.products = store.products.filter((p) => p.userId !== uid);
    saveStore(store);
    broadcastAll({ type: 'products:sync', products: store.products });
    res.json({ ok: true });
  });

  // Block / unblock user
  app.post('/api/users/:uid/block', (req, res) => {
    const user = store.users.find((u) => u.uid === req.params.uid);
    const { targetUserId } = req.body as { targetUserId?: string };
    if (!user || !targetUserId) {
      res.status(400).json({ error: 'Invalid request' });
      return;
    }
    if (!user.blockedUsers.includes(targetUserId)) {
      user.blockedUsers.push(targetUserId);
      saveStore(store);
    }
    res.json({ blockedUsers: user.blockedUsers });
  });

  app.post('/api/users/:uid/unblock', (req, res) => {
    const user = store.users.find((u) => u.uid === req.params.uid);
    const { targetUserId } = req.body as { targetUserId?: string };
    if (!user || !targetUserId) {
      res.status(400).json({ error: 'Invalid request' });
      return;
    }
    user.blockedUsers = user.blockedUsers.filter((id) => id !== targetUserId);
    saveStore(store);
    res.json({ blockedUsers: user.blockedUsers });
  });

  // Products CRUD
  app.get('/api/products', (_req, res) => {
    res.json({ products: store.products });
  });

  app.post('/api/products', (req, res) => {
    const { name, price, currency, description, photoURL, userId } = req.body as {
      name?: string;
      price?: string;
      currency?: string;
      description?: string;
      photoURL?: string;
      userId?: string;
    };

    const owner = store.users.find((u) => u.uid === userId);
    if (!owner) {
      res.status(401).json({ error: 'Authenticated user not found.' });
      return;
    }

    const trimmedName = (name || '').trim();
    const trimmedPrice = String(price ?? '').trim();
    const trimmedDesc = (description || '').trim();

    if (trimmedName.length < 2 || trimmedName.length > 8) {
      res.status(400).json({ error: 'Product name must be 2 to 8 characters.' });
      return;
    }
    if (!trimmedPrice || Number.isNaN(Number(trimmedPrice)) || Number(trimmedPrice) < 0) {
      res.status(400).json({ error: 'Please specify a valid price.' });
      return;
    }
    if (trimmedDesc.length > 0 && (trimmedDesc.length < 10 || trimmedDesc.length > 500)) {
      res.status(400).json({ error: 'Description must be 10 to 500 characters if provided.' });
      return;
    }

    const newProduct: StoredProduct = {
      id: `prod_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: trimmedName,
      price: trimmedPrice,
      currency: currency || '৳ TK',
      description: trimmedDesc,
      photoURL: photoURL || '',
      userId: owner.uid,
      username: owner.username,
      userPhoto: owner.photoURL,
      createdAt: new Date().toISOString(),
    };

    store.products.unshift(newProduct);
    saveStore(store);
    broadcastAll({ type: 'product:created', product: newProduct });
    res.status(201).json({ product: newProduct });
  });

  app.put('/api/products/:id', (req, res) => {
    const product = store.products.find((p) => p.id === req.params.id);
    if (!product) {
      res.status(404).json({ error: 'Product not found' });
      return;
    }

    const { userId, name, price, currency, description, photoURL } = req.body as {
      userId?: string;
      name?: string;
      price?: string;
      currency?: string;
      description?: string;
      photoURL?: string;
    };

    if (product.userId !== userId) {
      res.status(403).json({ error: 'Only the owner can edit this product.' });
      return;
    }

    const trimmedName = (name || '').trim();
    const trimmedPrice = String(price ?? '').trim();
    const trimmedDesc = (description || '').trim();

    if (trimmedName.length < 2 || trimmedName.length > 8) {
      res.status(400).json({ error: 'Product name must be 2 to 8 characters.' });
      return;
    }
    if (!trimmedPrice || Number.isNaN(Number(trimmedPrice)) || Number(trimmedPrice) < 0) {
      res.status(400).json({ error: 'Please specify a valid price.' });
      return;
    }
    if (trimmedDesc.length > 0 && (trimmedDesc.length < 10 || trimmedDesc.length > 500)) {
      res.status(400).json({ error: 'Description must be 10 to 500 characters if provided.' });
      return;
    }

    product.name = trimmedName;
    product.price = trimmedPrice;
    product.currency = currency || product.currency;
    product.description = trimmedDesc;
    if (photoURL) {
      product.photoURL = photoURL;
    }

    saveStore(store);
    broadcastAll({ type: 'product:updated', product });
    res.json({ product });
  });

  app.delete('/api/products/:id', (req, res) => {
    const idx = store.products.findIndex((p) => p.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'Product not found' });
      return;
    }
    const { userId } = req.body as { userId?: string };
    if (userId && store.products[idx].userId !== userId) {
      res.status(403).json({ error: 'Only the owner can delete this product.' });
      return;
    }
    const [removed] = store.products.splice(idx, 1);
    saveStore(store);
    broadcastAll({ type: 'product:deleted', productId: removed.id });
    res.json({ ok: true });
  });

  // Messages
  app.get('/api/messages', (req, res) => {
    const userId = String(req.query.userId || '');
    if (!userId) {
      res.json({ messages: [] });
      return;
    }
    const userMessages = store.messages.filter(
      (m) => m.senderId === userId || m.recipientId === userId
    );
    res.json({ messages: userMessages });
  });

  app.post('/api/messages', (req, res) => {
    const { senderId, recipientId, text, media, mediaType, mediaItems } = req.body as {
      senderId?: string;
      recipientId?: string;
      text?: string;
      media?: string;
      mediaType?: 'image' | 'video' | '';
      mediaItems?: StoredMediaItem[];
    };

    if (!senderId || !recipientId) {
      res.status(400).json({ error: 'Missing sender or recipient.' });
      return;
    }

    const sender = store.users.find((u) => u.uid === senderId);
    const recipient = store.users.find((u) => u.uid === recipientId);
    if (!sender || !recipient) {
      res.status(404).json({ error: 'Chat user not found.' });
      return;
    }

    if (sender.blockedUsers.includes(recipientId)) {
      res.status(403).json({ error: 'You have blocked this user. Unblock to send messages.' });
      return;
    }
    if (recipient.blockedUsers.includes(senderId)) {
      res.status(403).json({ error: 'You cannot send messages to this user.' });
      return;
    }

    const cleanText = (text || '').trim();
    const normalizedItems: StoredMediaItem[] = Array.isArray(mediaItems)
      ? mediaItems
          .filter((item) => item && typeof item.src === 'string' && item.src.length > 0)
          .slice(0, 20)
          .map((item) => ({
            src: item.src,
            mediaType: item.mediaType === 'video' || item.src.startsWith('data:video')
              ? 'video'
              : 'image',
          }))
      : [];

    if (normalizedItems.length === 0 && media) {
      normalizedItems.push({
        src: media,
        mediaType: mediaType === 'video' || media.startsWith('data:video') ? 'video' : 'image',
      });
    }

    if (!cleanText && normalizedItems.length === 0) {
      res.status(400).json({ error: 'Message cannot be empty.' });
      return;
    }

    const firstMedia = normalizedItems[0];
    const newMsg: StoredMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      threadKey: getThreadKey(senderId, recipientId),
      senderId,
      recipientId,
      text: cleanText,
      media: firstMedia ? firstMedia.src : '',
      mediaType: firstMedia ? firstMedia.mediaType : '',
      mediaItems: normalizedItems,
      timestamp: new Date().toISOString(),
      readBy: [senderId],
    };

    store.messages.push(newMsg);
    saveStore(store);

    broadcastToUsers([senderId, recipientId], {
      type: 'message:created',
      message: newMsg,
    });

    res.status(201).json({ message: newMsg });
  });

  app.post('/api/messages/read', (req, res) => {
    const { userId, peerId } = req.body as { userId?: string; peerId?: string };
    if (!userId || !peerId) {
      res.status(400).json({ error: 'Missing userId or peerId.' });
      return;
    }

    const threadKey = getThreadKey(userId, peerId);
    let updated = false;
    for (const msg of store.messages) {
      if (msg.threadKey === threadKey && msg.recipientId === userId) {
        if (!msg.readBy.includes(userId)) {
          msg.readBy.push(userId);
          updated = true;
        }
      }
    }

    if (updated) {
      saveStore(store);
      broadcastToUsers([userId, peerId], {
        type: 'messages:read',
        userId,
        peerId,
      });
    }

    res.json({ ok: true });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  httpServer.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Server failed to start:', err);
  process.exit(1);
});
