import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { SubscriptionGate } from './components/SubscriptionGate';
import { AuthModal } from './components/AuthModal';
import { TopBar } from './components/TopBar';
import { DashboardView } from './components/DashboardView';
import { ProductDetailView } from './components/ProductDetailView';
import { DirectChatView } from './components/DirectChatView';
import { ChatDrawer } from './components/ChatDrawer';
import { PhotoZoomModal } from './components/PhotoZoomModal';
import {
  DeleteAccountModal,
  ProfileEditModal,
  ProfileSideModal,
} from './components/ProfileModals';
import {
  CreateEditProductModal,
  ProductActionsModal,
  SearchModal,
} from './components/ProductModals';
import {
  buildConversationSummaries,
  countTotalUnread,
  getThreadKey,
} from './utils/marketplaceLogic';
import type {
  ChatMediaItem,
  ChatMessage,
  Product,
  PublicUser,
  ZoomMedia,
} from './types';

const SUB_STORAGE_KEY = 'ultra_sub_unlocked_v1';
const USER_STORAGE_KEY = 'business_auth_user_v1';

type ActiveView = 'dashboard' | 'detail' | 'chat';

export default function App() {
  const [subUnlocked, setSubUnlocked] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') return true;
    return localStorage.getItem(SUB_STORAGE_KEY) === 'true';
  });

  const [authUser, setAuthUser] = useState<PublicUser | null>(() => {
    if (typeof window === 'undefined') return null;
    try {
      const saved = localStorage.getItem(USER_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as PublicUser) : null;
    } catch {
      return null;
    }
  });

  const [users, setUsers] = useState<PublicUser[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const [activeView, setActiveView] = useState<ActiveView>('dashboard');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [chatPeer, setChatPeer] = useState<PublicUser | null>(null);

  const [chatDrawerOpen, setChatDrawerOpen] = useState(false);
  const [drawerSearchQuery, setDrawerSearchQuery] = useState('');
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [profileEditOpen, setProfileEditOpen] = useState(false);
  const [deleteAccountOpen, setDeleteAccountOpen] = useState(false);

  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [actionProduct, setActionProduct] = useState<Product | null>(null);
  const [zoomMedia, setZoomMedia] = useState<ZoomMedia | null>(null);

  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);
  const wsRef = useRef<WebSocket | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => {
      setToastMsg(null);
    }, 3800);
  }, []);

  const fetchMarketplaceData = useCallback(async (uid: string) => {
    try {
      const [usersRes, productsRes, messagesRes, meRes] = await Promise.all([
        fetch('/api/users'),
        fetch('/api/products'),
        fetch(`/api/messages?userId=${encodeURIComponent(uid)}`),
        fetch(`/api/users/${encodeURIComponent(uid)}`),
      ]);

      if (meRes.status === 404) {
        localStorage.removeItem(USER_STORAGE_KEY);
        setAuthUser(null);
        return;
      }

      if (usersRes.ok) {
        const data = (await usersRes.json()) as { users: PublicUser[] };
        setUsers(data.users);
      }
      if (productsRes.ok) {
        const data = (await productsRes.json()) as { products: Product[] };
        setProducts(data.products);
      }
      if (messagesRes.ok) {
        const data = (await messagesRes.json()) as { messages: ChatMessage[] };
        setMessages(data.messages);
      }
      if (meRes.ok) {
        const data = (await meRes.json()) as { user: PublicUser };
        setAuthUser(data.user);
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(data.user));
      }
    } catch (err) {
      console.error('Failed to sync marketplace data:', err);
    }
  }, []);

  useEffect(() => {
    if (!authUser) return;
    fetchMarketplaceData(authUser.uid);
  }, [authUser?.uid, fetchMarketplaceData]);

  // Real-time WebSocket connection for instant chat & product sync
  useEffect(() => {
    if (!authUser) return;
    let closedByUnmount = false;
    let reconnectTimer: number | null = null;

    const connect = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws-chat`);
      wsRef.current = ws;

      ws.onopen = () => {
        ws.send(JSON.stringify({ type: 'auth:identify', userId: authUser.uid }));
      };

      ws.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data) as {
            type: string;
            message?: ChatMessage;
            product?: Product;
            products?: Product[];
            productId?: string;
            user?: PublicUser;
            userId?: string;
            peerId?: string;
          };

          if (payload.type === 'message:created' && payload.message) {
            const incoming = payload.message;
            setMessages((prev) => {
              if (prev.some((m) => m.id === incoming.id)) return prev;
              return [...prev, incoming];
            });
          } else if (payload.type === 'messages:read' && payload.userId && payload.peerId) {
            const targetKey = getThreadKey(payload.userId, payload.peerId);
            const readerId = payload.userId;
            setMessages((prev) =>
              prev.map((m) =>
                m.threadKey === targetKey && !m.readBy.includes(readerId)
                  ? { ...m, readBy: [...m.readBy, readerId] }
                  : m
              )
            );
          } else if (payload.type === 'product:created' && payload.product) {
            const prod = payload.product;
            setProducts((prev) => (prev.some((p) => p.id === prod.id) ? prev : [prod, ...prev]));
          } else if (payload.type === 'product:updated' && payload.product) {
            const prod = payload.product;
            setProducts((prev) => prev.map((p) => (p.id === prod.id ? prod : p)));
          } else if (payload.type === 'product:deleted' && payload.productId) {
            const deletedId = payload.productId;
            setProducts((prev) => prev.filter((p) => p.id !== deletedId));
          } else if (payload.type === 'products:sync' && payload.products) {
            setProducts(payload.products);
          } else if (payload.type === 'user:updated' && payload.user) {
            const updatedUser = payload.user;
            setUsers((prev) => {
              const exists = prev.some((u) => u.uid === updatedUser.uid);
              return exists
                ? prev.map((u) => (u.uid === updatedUser.uid ? updatedUser : u))
                : [...prev, updatedUser];
            });
          }
        } catch {
          // Ignore malformed ws message
        }
      };

      ws.onclose = () => {
        if (!closedByUnmount) {
          reconnectTimer = window.setTimeout(connect, 2000);
        }
      };
    };

    connect();

    return () => {
      closedByUnmount = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, [authUser?.uid]);

  const markThreadAsRead = useCallback(
    async (peerId: string) => {
      if (!authUser) return;
      const targetKey = getThreadKey(authUser.uid, peerId);
      setMessages((prev) =>
        prev.map((m) =>
          m.threadKey === targetKey &&
          m.recipientId === authUser.uid &&
          !m.readBy.includes(authUser.uid)
            ? { ...m, readBy: [...m.readBy, authUser.uid] }
            : m
        )
      );
      try {
        await fetch('/api/messages/read', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: authUser.uid, peerId }),
        });
      } catch {
        // Ignore transient read error
      }
    },
    [authUser]
  );

  // Automatically mark incoming messages read while viewing that direct chat
  useEffect(() => {
    if (activeView === 'chat' && authUser && chatPeer) {
      const hasUnread = messages.some(
        (m) =>
          m.senderId === chatPeer.uid &&
          m.recipientId === authUser.uid &&
          !m.readBy.includes(authUser.uid)
      );
      if (hasUnread) {
        markThreadAsRead(chatPeer.uid);
      }
    }
  }, [activeView, authUser, chatPeer, messages, markThreadAsRead]);

  const conversationSummaries = useMemo(() => {
    if (!authUser) return [];
    return buildConversationSummaries({
      currentUserId: authUser.uid,
      users,
      messages,
      searchQuery: drawerSearchQuery,
    });
  }, [authUser, users, messages, drawerSearchQuery]);

  const allConversationSummaries = useMemo(() => {
    if (!authUser) return [];
    return buildConversationSummaries({
      currentUserId: authUser.uid,
      users,
      messages,
    });
  }, [authUser, users, messages]);

  const totalUnread = useMemo(
    () => countTotalUnread(allConversationSummaries),
    [allConversationSummaries]
  );

  const selectedProduct = useMemo(
    () => products.find((p) => p.id === selectedProductId) || null,
    [products, selectedProductId]
  );

  const activeThreadMessages = useMemo(() => {
    if (!authUser || !chatPeer) return [];
    const key = getThreadKey(authUser.uid, chatPeer.uid);
    return messages
      .filter((m) => m.threadKey === key)
      .sort(
        (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      );
  }, [authUser, chatPeer, messages]);

  const handleSubUnlock = () => {
    localStorage.setItem(SUB_STORAGE_KEY, 'true');
    setSubUnlocked(true);
  };

  const handleAuthSuccess = (user: PublicUser) => {
    localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
    setAuthUser(user);
    setActiveView('dashboard');
  };

  const handleOpenChatWithPeer = (peer: PublicUser) => {
    setChatPeer(peer);
    setChatDrawerOpen(false);
    setActiveView('chat');
    markThreadAsRead(peer.uid);
  };

  const handleOpenChatFromProduct = (product: Product) => {
    const matchedUser = users.find((u) => u.uid === product.userId);
    const peer: PublicUser = matchedUser || {
      uid: product.userId,
      username: product.username,
      photoURL: product.userPhoto,
    };
    handleOpenChatWithPeer(peer);
  };

  const handleSaveProduct = async (payload: {
    id?: string;
    name: string;
    price: string;
    currency: string;
    description: string;
    photoURL: string;
  }): Promise<{ ok: boolean; error?: string }> => {
    if (!authUser) return { ok: false, error: 'Not signed in.' };
    try {
      const isEdit = Boolean(payload.id);
      const url = isEdit ? `/api/products/${payload.id}` : '/api/products';
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...payload,
          userId: authUser.uid,
        }),
      });
      const data = (await res.json()) as { product?: Product; error?: string };
      if (!res.ok || !data.product) {
        return { ok: false, error: data.error || 'Failed to save product.' };
      }

      const saved = data.product;
      setProducts((prev) => {
        if (isEdit) return prev.map((p) => (p.id === saved.id ? saved : p));
        return prev.some((p) => p.id === saved.id) ? prev : [saved, ...prev];
      });
      setProductModalOpen(false);
      setEditingProduct(null);
      showToast(isEdit ? 'Product Updated!' : 'Product Created Successfully!');
      return { ok: true };
    } catch {
      return { ok: false, error: 'Network error while saving product.' };
    }
  };

  const handleDeleteProduct = async (product: Product) => {
    if (!authUser) return;
    try {
      const res = await fetch(`/api/products/${product.id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: authUser.uid }),
      });
      if (!res.ok) {
        showToast('Could not delete product.');
        return;
      }
      setProducts((prev) => prev.filter((p) => p.id !== product.id));
      setActionProduct(null);
      if (selectedProductId === product.id) {
        setSelectedProductId(null);
        setActiveView('dashboard');
      }
      showToast('Product deleted successfully!');
    } catch {
      showToast('Network error while deleting product.');
    }
  };

  const handleSendMessage = async (payload: {
    text: string;
    mediaItems: ChatMediaItem[];
  }): Promise<boolean> => {
    if (!authUser || !chatPeer) return false;
    const tempId = `temp_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const firstMedia = payload.mediaItems[0];
    const optimisticMsg: ChatMessage = {
      id: tempId,
      threadKey: getThreadKey(authUser.uid, chatPeer.uid),
      senderId: authUser.uid,
      recipientId: chatPeer.uid,
      text: payload.text,
      media: firstMedia ? firstMedia.src : '',
      mediaType: firstMedia ? firstMedia.mediaType : '',
      mediaItems: payload.mediaItems,
      timestamp: new Date().toISOString(),
      readBy: [authUser.uid],
    };

    // Instant optimistic append
    setMessages((prev) => [...prev, optimisticMsg]);

    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: authUser.uid,
          recipientId: chatPeer.uid,
          text: payload.text,
          mediaItems: payload.mediaItems,
        }),
      });
      const data = (await res.json()) as { message?: ChatMessage; error?: string };
      if (!res.ok || !data.message) {
        setMessages((prev) => prev.filter((m) => m.id !== tempId));
        showToast(data.error || 'Could not send message.');
        return false;
      }
      const created = data.message;
      setMessages((prev) => {
        const alreadySyncedViaWs = prev.some((m) => m.id === created.id);
        if (alreadySyncedViaWs) {
          return prev.filter((m) => m.id !== tempId);
        }
        return prev.map((m) => (m.id === tempId ? created : m));
      });
      return true;
    } catch {
      setMessages((prev) => prev.filter((m) => m.id !== tempId));
      showToast('Network error while sending message.');
      return false;
    }
  };

  const handleBlockUser = async (targetUserId: string) => {
    if (!authUser) return;
    try {
      const res = await fetch(`/api/users/${authUser.uid}/block`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetUserId }),
      });
      if (res.ok) {
        const data = (await res.json()) as { blockedUsers: string[] };
        const updated = { ...authUser, blockedUsers: data.blockedUsers };
        setAuthUser(updated);
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updated));
        showToast('User blocked');
      }
    } catch {
      showToast('Failed to block user.');
    }
  };

  const handleUnblockUser = async (targetUserId: string) => {
    if (!authUser) return;
    try {
      const res = await fetch(`/api/users/${authUser.uid}/unblock`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetUserId }),
      });
      if (res.ok) {
        const data = (await res.json()) as { blockedUsers: string[] };
        const updated = { ...authUser, blockedUsers: data.blockedUsers };
        setAuthUser(updated);
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updated));
        showToast('User unblocked');
      }
    } catch {
      showToast('Failed to unblock user.');
    }
  };

  const handleSaveProfile = async (payload: {
    username: string;
    photoURL: string;
    oldPassword?: string;
    newPassword?: string;
  }): Promise<{ ok: boolean; error?: string }> => {
    if (!authUser) return { ok: false, error: 'Not signed in.' };
    try {
      const res = await fetch(`/api/users/${authUser.uid}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { user?: PublicUser; error?: string };
      if (!res.ok || !data.user) {
        return { ok: false, error: data.error || 'Could not update profile.' };
      }
      setAuthUser(data.user);
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(data.user));
      setProfileEditOpen(false);
      showToast('Profile updated successfully!');
      fetchMarketplaceData(data.user.uid);
      return { ok: true };
    } catch {
      return { ok: false, error: 'Network error while updating profile.' };
    }
  };

  const handleSignOut = () => {
    localStorage.removeItem(USER_STORAGE_KEY);
    setProfileModalOpen(false);
    setAuthUser(null);
    setChatPeer(null);
    setSelectedProductId(null);
    setActiveView('dashboard');
  };

  const handleConfirmDeleteAccount = async () => {
    if (!authUser) return;
    try {
      await fetch(`/api/users/${authUser.uid}`, { method: 'DELETE' });
    } catch {
      // Proceed to clear local session
    }
    localStorage.removeItem(USER_STORAGE_KEY);
    setDeleteAccountOpen(false);
    setAuthUser(null);
    setChatPeer(null);
    setSelectedProductId(null);
    setActiveView('dashboard');
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {toastMsg && (
        <div
          role="status"
          className="fixed top-4 left-1/2 -translate-x-1/2 z-[60] bg-red-600 text-white text-xs font-medium px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2"
        >
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {!subUnlocked && <SubscriptionGate onUnlocked={handleSubUnlock} />}

      {subUnlocked && !authUser && (
        <AuthModal onSuccess={handleAuthSuccess} onToast={showToast} />
      )}

      {subUnlocked && authUser && (
        <div className="min-h-screen bg-[#f8f9fa]">
          <TopBar
            user={authUser}
            unreadCount={totalUnread}
            onOpenChatDrawer={() => setChatDrawerOpen(true)}
            onOpenProfileModal={() => setProfileModalOpen(true)}
            onOpenSearchModal={() => setSearchModalOpen(true)}
            onGoHome={() => {
              setSelectedProductId(null);
              setActiveView('dashboard');
            }}
          />

          {activeView === 'dashboard' && (
            <DashboardView
              currentUser={authUser}
              products={products}
              onOpenCreateProduct={() => {
                setEditingProduct(null);
                setProductModalOpen(true);
              }}
              onSelectProduct={(prod) => {
                setSelectedProductId(prod.id);
                setActiveView('detail');
              }}
              onOpenProductActions={(prod) => setActionProduct(prod)}
            />
          )}

          {activeView === 'detail' && selectedProduct && (
            <ProductDetailView
              product={selectedProduct}
              currentUser={authUser}
              onBack={() => setActiveView('dashboard')}
              onChatWithOwner={handleOpenChatFromProduct}
              onEditProduct={(prod) => {
                setEditingProduct(prod);
                setProductModalOpen(true);
              }}
              onDeleteProduct={handleDeleteProduct}
              onZoomPhoto={setZoomMedia}
            />
          )}

          {activeView === 'chat' && chatPeer && (
            <DirectChatView
              currentUser={authUser}
              recipient={chatPeer}
              messages={activeThreadMessages}
              isBlocked={Boolean(authUser.blockedUsers?.includes(chatPeer.uid))}
              onBack={() => setActiveView('dashboard')}
              onSendMessage={handleSendMessage}
              onBlockUser={handleBlockUser}
              onUnblockUser={handleUnblockUser}
              onZoomPhoto={setZoomMedia}
            />
          )}

          <ChatDrawer
            open={chatDrawerOpen}
            summaries={conversationSummaries}
            searchQuery={drawerSearchQuery}
            onSearchChange={setDrawerSearchQuery}
            onSelectPeer={handleOpenChatWithPeer}
            onClose={() => setChatDrawerOpen(false)}
          />

          <ProfileSideModal
            open={profileModalOpen}
            user={authUser}
            onClose={() => setProfileModalOpen(false)}
            onOpenEditor={() => {
              setProfileModalOpen(false);
              setProfileEditOpen(true);
            }}
            onSignOut={handleSignOut}
            onPromptDelete={() => {
              setProfileModalOpen(false);
              setDeleteAccountOpen(true);
            }}
          />

          <ProfileEditModal
            open={profileEditOpen}
            user={authUser}
            onClose={() => setProfileEditOpen(false)}
            onSave={handleSaveProfile}
          />

          <DeleteAccountModal
            open={deleteAccountOpen}
            onConfirm={handleConfirmDeleteAccount}
            onCancel={() => setDeleteAccountOpen(false)}
          />

          <CreateEditProductModal
            open={productModalOpen}
            editingProduct={editingProduct}
            onClose={() => {
              setProductModalOpen(false);
              setEditingProduct(null);
            }}
            onSave={handleSaveProduct}
          />

          <ProductActionsModal
            product={actionProduct}
            onEdit={(prod) => {
              setActionProduct(null);
              setEditingProduct(prod);
              setProductModalOpen(true);
            }}
            onDelete={handleDeleteProduct}
            onClose={() => setActionProduct(null)}
          />

          <SearchModal
            open={searchModalOpen}
            products={products}
            onSelectProduct={(prod) => {
              setSelectedProductId(prod.id);
              setActiveView('detail');
            }}
            onClose={() => setSearchModalOpen(false)}
          />

          <PhotoZoomModal media={zoomMedia} onClose={() => setZoomMedia(null)} />
        </div>
      )}
    </div>
  );
}
