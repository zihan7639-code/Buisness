import { ArrowLeft, MessageCircle, Pencil, Trash2, ZoomIn } from 'lucide-react';
import type { Product, PublicUser, ZoomMedia } from '../types';

interface ProductDetailViewProps {
  product: Product;
  currentUser: PublicUser;
  onBack: () => void;
  onChatWithOwner: (product: Product) => void;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (product: Product) => void;
  onZoomPhoto: (media: ZoomMedia) => void;
}

export function ProductDetailView({
  product,
  currentUser,
  onBack,
  onChatWithOwner,
  onEditProduct,
  onDeleteProduct,
  onZoomPhoto,
}: ProductDetailViewProps) {
  const isOwner = product.userId === currentUser.uid;
  const priceDisplay = product.price ? `${product.currency} ${product.price}` : 'Free';

  return (
    <div className="min-h-[calc(100vh-65px)] bg-[#f8f9fa] text-gray-900 px-4 py-6">
      <div className="max-w-2xl mx-auto bg-white border border-gray-200 rounded-2xl p-4 sm:p-6 shadow-xs">
        <div className="flex items-center gap-3 border-b border-gray-200 pb-3 mb-4">
          <button
            type="button"
            onClick={onBack}
            aria-label="Back to dashboard"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center hover:bg-gray-100 rounded-full transition cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h2 className="text-lg font-bold text-gray-900 truncate">{product.name}</h2>
        </div>

        <div className="space-y-4">
          {product.photoURL ? (
            <button
              type="button"
              onClick={() =>
                onZoomPhoto({
                  src: product.photoURL,
                  alt: product.name,
                  subtitle: `${priceDisplay} · Listed by ${product.username}`,
                })
              }
              aria-label={`Zoom in on ${product.name} photo`}
              className="relative group w-full rounded-xl overflow-hidden border border-gray-200 bg-gray-100 cursor-zoom-in block"
            >
              <img
                src={product.photoURL}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-full max-h-80 object-cover transition-transform duration-200 group-hover:scale-[1.01]"
              />
              <span className="absolute bottom-3 right-3 inline-flex items-center gap-1.5 bg-black/75 text-white text-xs font-medium px-2.5 py-1.5 rounded-lg">
                <ZoomIn className="w-3.5 h-3.5" />
                Tap to zoom
              </span>
            </button>
          ) : (
            <div className="w-full h-56 rounded-xl border border-gray-200 bg-gray-100 flex items-center justify-center text-sm text-gray-400">
              No photo provided
            </div>
          )}

          <div className="flex items-start justify-between gap-4">
            <h1 className="text-2xl font-bold text-gray-900">{product.name}</h1>
            <span className="text-lg font-bold text-blue-600 tabular-nums whitespace-nowrap">
              {priceDisplay}
            </span>
          </div>

          <p className="text-gray-600 text-sm leading-relaxed whitespace-pre-wrap">
            {product.description || 'No description provided.'}
          </p>

          <div className="flex items-center justify-between gap-4 bg-gray-50 border border-gray-200 p-4 rounded-xl mt-4">
            <div className="flex items-center gap-3 min-w-0">
              {product.userPhoto ? (
                <img
                  src={product.userPhoto}
                  alt={product.username}
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-full object-cover border border-gray-300 shrink-0"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-blue-600 text-white font-semibold flex items-center justify-center shrink-0">
                  {product.username.slice(0, 1).toUpperCase()}
                </div>
              )}
              <div className="min-w-0">
                <p className="text-xs text-gray-500 font-medium">Created by</p>
                <h4 className="font-bold text-gray-900 text-base truncate">
                  {product.username}
                </h4>
              </div>
            </div>

            {isOwner ? (
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onEditProduct(product)}
                  className="min-h-[42px] bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 px-3.5 py-2 rounded-lg font-semibold text-sm transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Pencil className="w-4 h-4" />
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteProduct(product)}
                  className="min-h-[42px] bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-semibold text-sm transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => onChatWithOwner(product)}
                className="min-h-[44px] bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg font-semibold text-sm transition flex items-center gap-2 cursor-pointer shrink-0"
              >
                <MessageCircle className="w-4 h-4" />
                Chat
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
