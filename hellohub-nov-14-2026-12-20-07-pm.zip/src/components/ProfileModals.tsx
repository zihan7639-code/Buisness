import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import { LogOut, Pencil, Trash2, X } from 'lucide-react';
import { validatePasswordChange } from '../utils/marketplaceLogic';
import type { PublicUser } from '../types';

interface ProfileSideModalProps {
  open: boolean;
  user: PublicUser;
  onClose: () => void;
  onOpenEditor: () => void;
  onSignOut: () => void;
  onPromptDelete: () => void;
}

export function ProfileSideModal({
  open,
  user,
  onClose,
  onOpenEditor,
  onSignOut,
  onPromptDelete,
}: ProfileSideModalProps) {
  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="User profile"
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex"
    >
      <div className="bg-white text-gray-900 w-80 max-w-[85vw] h-full shadow-2xl flex flex-col p-6">
        <div className="flex items-center justify-between mb-6">
          <span className="text-sm font-semibold text-gray-500">Account</span>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close profile"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center text-gray-600 hover:text-gray-900 rounded-full hover:bg-gray-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex flex-col items-center flex-1 text-center space-y-4">
          {user.photoURL ? (
            <img
              src={user.photoURL}
              alt={user.username}
              referrerPolicy="no-referrer"
              className="w-28 h-28 rounded-full object-cover border-4 border-blue-500 shadow-md"
            />
          ) : (
            <div className="w-28 h-28 rounded-full bg-blue-600 text-white text-3xl font-bold flex items-center justify-center border-4 border-blue-200">
              {user.username.slice(0, 1).toUpperCase()}
            </div>
          )}

          <h3 className="text-xl font-bold text-gray-900">{user.username}</h3>

          <div className="flex items-center gap-3 pt-4">
            <button
              type="button"
              onClick={onOpenEditor}
              aria-label="Edit profile"
              title="Edit Profile"
              className="min-w-[48px] min-h-[48px] bg-blue-50 hover:bg-blue-100 text-blue-600 border border-blue-200 p-3 rounded-xl flex items-center justify-center transition cursor-pointer"
            >
              <Pencil className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={onSignOut}
              aria-label="Switch account"
              title="Switch Account"
              className="min-w-[48px] min-h-[48px] bg-gray-100 hover:bg-gray-200 text-gray-700 border border-gray-200 p-3 rounded-xl flex items-center justify-center transition cursor-pointer"
            >
              <LogOut className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={onPromptDelete}
              aria-label="Delete account"
              title="Delete Account"
              className="min-w-[48px] min-h-[48px] bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 p-3 rounded-xl flex items-center justify-center transition cursor-pointer"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <button
        type="button"
        aria-label="Dismiss profile drawer"
        onClick={onClose}
        className="flex-1 cursor-default"
      />
    </div>
  );
}

interface ProfileEditModalProps {
  open: boolean;
  user: PublicUser;
  onClose: () => void;
  onSave: (payload: {
    username: string;
    photoURL: string;
    oldPassword?: string;
    newPassword?: string;
  }) => Promise<{ ok: boolean; error?: string }>;
}

export function ProfileEditModal({
  open,
  user,
  onClose,
  onSave,
}: ProfileEditModalProps) {
  const [avatar, setAvatar] = useState(user.photoURL);
  const [username, setUsername] = useState(user.username);
  const [showPasswordSection, setShowPasswordSection] = useState(false);
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setAvatar(user.photoURL);
      setUsername(user.username);
      setShowPasswordSection(false);
      setOldPass('');
      setNewPass('');
      setConfirmPass('');
      setErrorMsg('');
    }
  }, [open, user]);

  if (!open) return null;

  const handleAvatarChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      if (typeof ev.target?.result === 'string') {
        setAvatar(ev.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const trimmed = username.trim();
    if (trimmed.length < 2 || trimmed.length > 16) {
      setErrorMsg('Username must be 2 to 16 characters.');
      return;
    }

    if (showPasswordSection) {
      const check = validatePasswordChange({
        oldPassword: oldPass,
        newPassword: newPass,
        confirmPassword: confirmPass,
      });
      if (!check.valid) {
        setErrorMsg(check.error || 'Invalid password.');
        return;
      }
    }

    setSaving(true);
    const result = await onSave({
      username: trimmed,
      photoURL: avatar,
      oldPassword: showPasswordSection ? oldPass : undefined,
      newPassword: showPasswordSection ? newPass : undefined,
    });
    setSaving(false);

    if (!result.ok) {
      setErrorMsg(result.error || 'Could not update profile.');
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Edit profile and password"
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <form
        onSubmit={handleSubmit}
        className="bg-white text-gray-900 rounded-xl p-6 w-full max-w-sm shadow-2xl space-y-4"
      >
        <h3 className="text-lg font-bold text-gray-900">Edit Profile & Password</h3>

        <div className="text-center">
          <label
            htmlFor="edit-profile-pic"
            aria-label="Change profile picture"
            className="relative w-20 h-20 mx-auto rounded-full bg-gray-100 border-2 border-blue-500 overflow-hidden flex items-center justify-center cursor-pointer"
          >
            <img
              src={avatar}
              alt="Profile avatar"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <input
              id="edit-profile-pic"
              type="file"
              accept="image/*"
              onChange={handleAvatarChange}
              className="sr-only"
            />
          </label>
        </div>

        <div>
          <label
            htmlFor="edit-username-input"
            className="block text-xs font-bold text-gray-600 uppercase mb-1"
          >
            Username
          </label>
          <input
            id="edit-username-input"
            type="text"
            minLength={2}
            maxLength={16}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="border-t border-gray-200 pt-3">
          <button
            type="button"
            onClick={() => setShowPasswordSection((prev) => !prev)}
            className="text-blue-600 hover:underline text-xs font-bold uppercase cursor-pointer"
          >
            Change Password
          </button>

          {showPasswordSection && (
            <div className="space-y-3 mt-3 bg-gray-50 p-3 rounded-lg border border-gray-200">
              <div>
                <label
                  htmlFor="edit-old-pass"
                  className="block text-[10px] font-bold text-gray-600 uppercase mb-1"
                >
                  Write your first password
                </label>
                <input
                  id="edit-old-pass"
                  type="password"
                  value={oldPass}
                  onChange={(e) => setOldPass(e.target.value)}
                  placeholder="Current Password"
                  className="w-full border border-gray-300 rounded-lg p-2 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label
                  htmlFor="edit-new-pass"
                  className="block text-[10px] font-bold text-gray-600 uppercase mb-1"
                >
                  New Password
                </label>
                <input
                  id="edit-new-pass"
                  type="password"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  placeholder="New Password (2-16 chars)"
                  className="w-full border border-gray-300 rounded-lg p-2 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label
                  htmlFor="edit-confirm-pass"
                  className="block text-[10px] font-bold text-gray-600 uppercase mb-1"
                >
                  Confirm New Password
                </label>
                <input
                  id="edit-confirm-pass"
                  type="password"
                  value={confirmPass}
                  onChange={(e) => setConfirmPass(e.target.value)}
                  placeholder="Confirm Password"
                  className="w-full border border-gray-300 rounded-lg p-2 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="text-gray-500 hover:underline text-sm font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold px-4 py-2 rounded-lg transition cursor-pointer"
          >
            {saving ? 'Saving...' : 'Save'}
          </button>
        </div>

        <div role="alert" className="text-xs text-red-500 text-center min-h-[16px]">
          {errorMsg}
        </div>
      </form>
    </div>
  );
}

interface DeleteAccountModalProps {
  open: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export function DeleteAccountModal({
  open,
  onConfirm,
  onCancel,
}: DeleteAccountModalProps) {
  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Confirm delete account"
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <div className="bg-white text-gray-900 rounded-xl p-6 w-full max-w-xs text-center shadow-2xl space-y-4">
        <h3 className="text-base font-bold text-gray-800">
          Do you want to delete your account?
        </h3>
        <div className="flex items-center justify-center gap-6 pt-2">
          <button
            type="button"
            onClick={onConfirm}
            className="text-red-600 font-bold text-base hover:underline cursor-pointer"
          >
            Yes
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="text-blue-600 font-bold text-base hover:underline cursor-pointer"
          >
            No
          </button>
        </div>
      </div>
    </div>
  );
}
