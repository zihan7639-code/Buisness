import { useRef } from 'react';
import { ChevronDown, ChevronRight, MoreHorizontal, PlusSquare } from 'lucide-react';
import type { Product, PublicUser } from '../types';

interface DashboardViewProps {
  currentUser: PublicUser;
  products: Product[];
  onOpenCreateProduct: () => void;
  onSelectProduct: (product: Product) => void;
  onOpenProductActions: (product: Product) => void;
}

export function DashboardView({
  currentUser,
  products,
  onOpenCreateProduct,
  onSelectProduct,
  onOpenProductActions,
}: DashboardViewProps) {
  const pressTimerRef = useRef<number | null>(null);

  const yourProducts = products.filter((p) => p.userId === currentUser.uid);
  const otherProducts = products.filter((p) => p.userId !== currentUser.uid);

  const startLongPress = (product: Product) => {
    if (pressTimerRef.current) window.clearTimeout(pressTimerRef.current);
    pressTimerRef.current = window.setTimeout(() => {
      onOpenProductActions(product);
    }, 500);
  };

  const cancelLongPress = () => {
    if (pressTimerRef.current) {
      window.clearTimeout(pressTimerRef.current);
      pressTimerRef.current = null;
    }
  };

  return (
    <main className="bg-[#f8f9fa] text-gray-900 min-h-[calc(100vh-65px)]">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-8">
        <section aria-labelledby="your-products-heading">
          <div className="flex items-center gap-1.5 mb-3">
            <h2
              id="your-products-heading"
              className="text-base font-semibold text-gray-800"
            >
              Your
            </h2>
            <ChevronRight className="w-4 h-4 text-gray-500" aria-hidden="true" />
          </div>

          <div
            className="flex gap-4 overflow-x-auto pb-2"
            data-testid="your-products-list"
          >
            <button
              type="button"
              onClick={onOpenCreateProduct}
              className="min-w-[160px] w-[160px] h-[204px] bg-white border-2 border-dashed border-blue-600 rounded-xl flex flex-col items-center justify-center gap-1.5 text-blue-600 hover:bg-blue-50/70 transition cursor-pointer shrink-0"
            >
              <PlusSquare className="w-9 h-9" />
              <span className="text-xs font-semibold">Create</span>
            </button>

            {yourProducts.map((item) => {
              const priceDisplay = item.price
                ? `${item.currency} ${item.price}`
                : 'Free';
              return (
                <div
                  key={item.id}
                  onTouchStart={() => startLongPress(item)}
                  onTouchEnd={cancelLongPress}
                  onTouchMove={cancelLongPress}
                  className="relative min-w-[164px] w-[164px] h-[204px] bg-white border border-gray-200 rounded-xl p-2 flex flex-col hover:-translate-y-0.5 hover:shadow-md transition shrink-0"
                >
                  <button
                    type="button"
                    onClick={() => onSelectProduct(item)}
                    aria-label={`View your product ${item.name}`}
                    className="flex-1 flex flex-col text-left cursor-pointer w-full"
                  >
                    <div className="w-full aspect-[4/3] bg-gray-100 rounded-lg overflow-hidden shrink-0 flex items-center justify-center">
                      {item.photoURL ? (
                        <img
                          src={item.photoURL}
                          alt={item.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-xs font-medium text-gray-400">
                          No photo
                        </span>
                      )}
                    </div>
                    <div className="pt-2.5 px-1 text-center w-full">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        {item.name}
                      </p>
                      <p className="text-xs font-bold text-blue-600 tabular-nums truncate mt-0.5">
                        {priceDisplay}
                      </p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => onOpenProductActions(item)}
                    aria-label={`Manage ${item.name}`}
                    className="absolute top-3 right-3 w-7 h-7 rounded-full bg-white/90 border border-gray-200 text-gray-700 hover:text-gray-950 flex items-center justify-center shadow-xs cursor-pointer"
                  >
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        </section>

        <section aria-labelledby="others-products-heading">
          <div className="flex items-center gap-1.5 mb-3">
            <h2
              id="others-products-heading"
              className="text-base font-semibold text-gray-800"
            >
              Others
            </h2>
            <ChevronDown className="w-4 h-4 text-gray-500" aria-hidden="true" />
          </div>

          {otherProducts.length === 0 ? (
            <div className="bg-white border border-gray-200 rounded-xl p-8 text-center text-sm text-gray-500">
              No products from other sellers yet.
            </div>
          ) : (
            <div
              className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4"
              data-testid="others-products-list"
            >
              {otherProducts.map((item) => {
                const priceDisplay = item.price
                  ? `${item.currency} ${item.price}`
                  : 'Free';
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onSelectProduct(item)}
                    aria-label={`View ${item.name} by ${item.username}`}
                    className="bg-white border border-gray-200 rounded-xl p-2.5 flex flex-col justify-between text-left hover:-translate-y-0.5 hover:shadow-md transition cursor-pointer"
                  >
                    <div className="w-full aspect-[4/3] bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center">
                      {item.photoURL ? (
                        <img
                          src={item.photoURL}
                          alt={item.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-xs font-medium text-gray-400">
                          No photo
                        </span>
                      )}
                    </div>
                    <div className="pt-2.5 px-1 space-y-0.5">
                      <p className="text-sm font-semibold text-gray-900 truncate">
                        {item.name}
                      </p>
                      <p className="text-xs text-gray-500 truncate">{item.username}</p>
                      <p className="text-xs font-bold text-blue-600 tabular-nums truncate pt-0.5">
                        {priceDisplay}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
