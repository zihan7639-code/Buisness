import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import { Pencil, PlusSquare, Trash2, X } from 'lucide-react';
import {
  CURRENCY_OPTIONS,
  filterProducts,
  validateProductInput,
} from '../utils/marketplaceLogic';
import type { Product } from '../types';

interface CreateEditProductModalProps {
  open: boolean;
  editingProduct: Product | null;
  onClose: () => void;
  onSave: (payload: {
    id?: string;
    name: string;
    price: string;
    currency: string;
    description: string;
    photoURL: string;
  }) => Promise<{ ok: boolean; error?: string }>;
}

export function CreateEditProductModal({
  open,
  editingProduct,
  onClose,
  onSave,
}: CreateEditProductModalProps) {
  const [name, setName] = useState('');
  const [currency, setCurrency] = useState<string>('৳ TK');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [photoURL, setPhotoURL] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (editingProduct) {
      setName(editingProduct.name);
      setCurrency(editingProduct.currency || '৳ TK');
      setPrice(editingProduct.price);
      setDescription(editingProduct.description || '');
      setPhotoURL(editingProduct.photoURL || '');
    } else {
      setName('');
      setCurrency('৳ TK');
      setPrice('');
      setDescription('');
      setPhotoURL('');
    }
    setErrorMsg('');
  }, [open, editingProduct]);

  if (!open) return null;

  const handlePhotoChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      if (typeof ev.target?.result === 'string') {
        setPhotoURL(ev.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const check = validateProductInput({ name, price, description });
    if (!check.valid) {
      setErrorMsg(check.error || 'Please check product fields.');
      return;
    }

    setSaving(true);
    const result = await onSave({
      id: editingProduct?.id,
      name: name.trim(),
      price: price.trim(),
      currency,
      description: description.trim(),
      photoURL,
    });
    setSaving(false);

    if (!result.ok) {
      setErrorMsg(result.error || 'Could not save product.');
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={editingProduct ? 'Edit Product' : 'Create Product'}
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <form
        onSubmit={handleSubmit}
        className="bg-white text-gray-900 rounded-xl p-6 w-full max-w-md shadow-2xl"
      >
        <h2 className="text-xl font-bold mb-4 text-gray-900">
          {editingProduct ? 'Edit Product' : 'Create Product'}
        </h2>

        <div className="mb-3 text-left">
          <label
            htmlFor="prod-name-input"
            className="block text-xs font-bold text-gray-600 uppercase mb-1"
          >
            Product Name (2-8 chars) *
          </label>
          <input
            id="prod-name-input"
            type="text"
            minLength={2}
            maxLength={8}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Phone"
            className="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="grid grid-cols-3 gap-2 mb-3 text-left">
          <div className="col-span-1">
            <label
              htmlFor="prod-currency-input"
              className="block text-xs font-bold text-gray-600 uppercase mb-1"
            >
              Currency *
            </label>
            <select
              id="prod-currency-input"
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:outline-none focus:border-blue-500 bg-white"
            >
              {CURRENCY_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
          </div>
          <div className="col-span-2">
            <label
              htmlFor="prod-price-input"
              className="block text-xs font-bold text-gray-600 uppercase mb-1"
            >
              Price *
            </label>
            <input
              id="prod-price-input"
              type="number"
              min="0"
              step="any"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="e.g. 500"
              className="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <div className="mb-3 text-left">
          <label
            htmlFor="prod-desc-input"
            className="block text-xs font-bold text-gray-600 uppercase mb-1"
          >
            Description (Optional, 10-500 chars)
          </label>
          <textarea
            id="prod-desc-input"
            maxLength={500}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Product details..."
            className="w-full border border-gray-300 rounded-lg p-2.5 text-sm h-20 resize-none focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="mb-5 text-left">
          <span className="block text-xs font-bold text-gray-600 uppercase mb-1">
            Product Photo
          </span>
          <label
            htmlFor="prod-photo-input"
            className="relative w-full h-28 border-2 border-dashed border-gray-300 hover:border-blue-500 rounded-lg flex flex-col items-center justify-center cursor-pointer bg-gray-50 overflow-hidden"
          >
            {photoURL ? (
              <img
                src={photoURL}
                alt="Product preview"
                className="w-full h-full object-cover"
              />
            ) : (
              <>
                <PlusSquare className="w-7 h-7 text-gray-500" />
                <span className="text-xs text-gray-500 mt-1">Add Photo</span>
              </>
            )}
          </label>
          <input
            id="prod-photo-input"
            type="file"
            accept="image/*"
            onChange={handlePhotoChange}
            className="sr-only"
          />
        </div>

        <div className="flex items-center justify-end gap-4">
          <button
            type="button"
            onClick={onClose}
            className="text-blue-600 hover:underline text-sm font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition cursor-pointer"
          >
            {saving ? 'Saving...' : editingProduct ? 'Save' : 'Create'}
          </button>
        </div>

        <div role="alert" className="text-xs text-red-500 mt-3 text-center min-h-[16px]">
          {errorMsg}
        </div>
      </form>
    </div>
  );
}

interface ProductActionsModalProps {
  product: Product | null;
  onEdit: (product: Product) => void;
  onDelete: (product: Product) => void;
  onClose: () => void;
}

export function ProductActionsModal({
  product,
  onEdit,
  onDelete,
  onClose,
}: ProductActionsModalProps) {
  if (!product) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Product options"
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <div className="bg-white text-gray-900 rounded-xl p-6 w-full max-w-xs text-center shadow-2xl space-y-4">
        <h3 className="text-base font-bold text-gray-800">{product.name}</h3>

        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => onEdit(product)}
            className="bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 font-bold py-3 px-4 rounded-xl flex flex-col items-center justify-center gap-1 transition cursor-pointer"
          >
            <Pencil className="w-5 h-5" />
            Edit
          </button>
          <button
            type="button"
            onClick={() => onDelete(product)}
            className="bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 font-bold py-3 px-4 rounded-xl flex flex-col items-center justify-center gap-1 transition cursor-pointer"
          >
            <Trash2 className="w-5 h-5" />
            Delete
          </button>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full text-gray-500 text-xs font-semibold py-2 hover:underline cursor-pointer"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}

interface SearchModalProps {
  open: boolean;
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onClose: () => void;
}

export function SearchModal({
  open,
  products,
  onSelectProduct,
  onClose,
}: SearchModalProps) {
  const [query, setQuery] = useState('');

  useEffect(() => {
    if (open) setQuery('');
  }, [open]);

  if (!open) return null;

  const matches = filterProducts(products, query);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Search products"
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <div className="bg-white text-gray-900 rounded-xl p-6 w-full max-w-md shadow-2xl space-y-4">
        <div className="flex justify-between items-center border-b border-gray-200 pb-2">
          <h3 className="font-bold text-gray-800 text-base">Search Products</h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close search"
            className="min-w-[36px] min-h-[36px] flex items-center justify-center text-gray-500 hover:text-gray-900 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <label htmlFor="search-input-field" className="sr-only">
          Type product name
        </label>
        <input
          id="search-input-field"
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Type product name..."
          autoFocus
          className="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:outline-none focus:border-blue-500"
        />

        <div className="max-h-64 overflow-y-auto space-y-2">
          {!query.trim() ? (
            <p className="text-xs text-gray-400 text-center py-4">
              Search by product name or seller
            </p>
          ) : matches.length === 0 ? (
            <p className="text-xs text-gray-500 text-center py-4">No products found.</p>
          ) : (
            matches.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onClose();
                  onSelectProduct(item);
                }}
                className="w-full flex items-center gap-3 p-2 hover:bg-gray-100 rounded-lg cursor-pointer text-left"
              >
                {item.photoURL ? (
                  <img
                    src={item.photoURL}
                    alt={item.name}
                    referrerPolicy="no-referrer"
                    className="w-11 h-11 rounded object-cover shrink-0"
                  />
                ) : (
                  <div className="w-11 h-11 rounded bg-gray-100 border border-gray-200 flex items-center justify-center text-[10px] text-gray-400 shrink-0">
                    None
                  </div>
                )}
                <div className="min-w-0">
                  <p className="text-sm font-bold text-gray-900 truncate">{item.name}</p>
                  <p className="text-xs text-blue-600 font-semibold tabular-nums">
                    {item.currency} {item.price}
                  </p>
                </div>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
