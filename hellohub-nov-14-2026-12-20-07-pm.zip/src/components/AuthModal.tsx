import { useState, type ChangeEvent, type FormEvent } from 'react';
import { Plus } from 'lucide-react';
import { validateAuthInput } from '../utils/marketplaceLogic';
import type { PublicUser } from '../types';

interface AuthModalProps {
  onSuccess: (user: PublicUser) => void;
  onToast: (message: string) => void;
}

export function AuthModal({ onSuccess, onToast }: AuthModalProps) {
  const [avatarData, setAvatarData] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleAvatarChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      if (typeof ev.target?.result === 'string') {
        setAvatarData(ev.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleCreate = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const check = validateAuthInput({
      username,
      password,
      hasAvatar: Boolean(avatarData),
    });
    if (!check.valid) {
      if (check.toastError) onToast(check.toastError);
      if (check.error) setErrorMsg(check.error);
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: username.trim(),
          password,
          photoURL: avatarData,
        }),
      });
      const data = (await res.json()) as { user?: PublicUser; error?: string };
      if (!res.ok || !data.user) {
        setErrorMsg(data.error || 'Could not create account.');
        return;
      }
      onSuccess(data.user);
    } catch {
      setErrorMsg('Network error while creating account.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSignIn = async () => {
    setErrorMsg('');
    if (!avatarData) {
      onToast('Please put your profile picture');
      return;
    }
    if (!username.trim() || !password) {
      setErrorMsg('Enter your username and password.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: username.trim(),
          password,
          photoURL: avatarData,
        }),
      });
      const data = (await res.json()) as { user?: PublicUser; error?: string };
      if (!res.ok || !data.user) {
        setErrorMsg(data.error || 'Account not found or incorrect credentials!');
        return;
      }
      onSuccess(data.user);
    } catch {
      setErrorMsg('Network error while signing in.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-40 bg-black/95 backdrop-blur-md flex items-center justify-center p-4">
      <form
        onSubmit={handleCreate}
        className="bg-zinc-900 border border-green-500/50 rounded-2xl p-6 w-full max-w-sm text-center shadow-[0_0_30px_rgba(0,255,65,0.15)] space-y-4"
      >
        <h2 className="text-xl font-bold font-cyber-mono text-green-400">ACCOUNT ACCESS</h2>

        <label
          htmlFor="auth-profile-pic"
          className="relative w-20 h-20 mx-auto rounded-full bg-zinc-800 border-2 border-green-500 overflow-hidden flex items-center justify-center cursor-pointer hover:border-green-400 transition"
          aria-label="Upload profile picture"
        >
          {avatarData ? (
            <img
              src={avatarData}
              alt="Profile preview"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          ) : (
            <Plus className="w-7 h-7 text-green-400" />
          )}
          <input
            id="auth-profile-pic"
            type="file"
            accept="image/*"
            onChange={handleAvatarChange}
            className="sr-only"
          />
        </label>
        <p className="text-xs text-zinc-400 font-cyber-mono">
          Tap circle to add profile picture
        </p>

        <div className="space-y-3 text-left">
          <div>
            <label htmlFor="auth-username" className="sr-only">
              Username
            </label>
            <input
              id="auth-username"
              type="text"
              minLength={2}
              maxLength={16}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username (2-16 chars)"
              className="w-full bg-black border border-white/20 rounded-lg px-3.5 py-3 text-white placeholder:text-zinc-500 focus:outline-none focus:border-green-400 text-sm font-cyber-mono"
            />
          </div>
          <div>
            <label htmlFor="auth-password" className="sr-only">
              Password
            </label>
            <input
              id="auth-password"
              type="password"
              minLength={2}
              maxLength={16}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password (2-16 chars)"
              className="w-full bg-black border border-white/20 rounded-lg px-3.5 py-3 text-white placeholder:text-zinc-500 focus:outline-none focus:border-green-400 text-sm font-cyber-mono"
            />
          </div>
        </div>

        <div className="space-y-2.5 pt-1">
          <button
            type="submit"
            disabled={submitting}
            className="w-full min-h-[44px] bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-bold py-3 rounded-lg font-cyber-mono uppercase text-sm transition cursor-pointer"
          >
            {submitting ? 'Please wait...' : 'Create'}
          </button>
          <button
            type="button"
            disabled={submitting}
            onClick={handleSignIn}
            className="w-full min-h-[44px] bg-transparent hover:bg-white/5 disabled:opacity-60 text-blue-400 border border-blue-500 font-bold py-2.5 rounded-lg font-cyber-mono uppercase text-xs transition cursor-pointer"
          >
            Sign In
          </button>
        </div>

        <div
          role="alert"
          className="text-xs font-cyber-mono text-red-400 min-h-[16px]"
        >
          {errorMsg}
        </div>
      </form>
    </div>
  );
}
