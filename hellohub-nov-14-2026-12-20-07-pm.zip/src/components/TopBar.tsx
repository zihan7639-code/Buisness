import { Menu, Search } from 'lucide-react';
import type { PublicUser } from '../types';

interface TopBarProps {
  user: PublicUser;
  unreadCount: number;
  onOpenChatDrawer: () => void;
  onOpenProfileModal: () => void;
  onOpenSearchModal: () => void;
  onGoHome: () => void;
}

export function TopBar({
  user,
  unreadCount,
  onOpenChatDrawer,
  onOpenProfileModal,
  onOpenSearchModal,
  onGoHome,
}: TopBarProps) {
  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-4 px-4 sm:px-6 py-2.5 bg-white border-b border-gray-200 text-gray-900">
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onOpenChatDrawer}
          aria-label="Open messages menu"
          className="relative min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full text-gray-700 hover:text-gray-950 hover:bg-gray-100 transition cursor-pointer shrink-0"
        >
          <Menu className="w-6 h-6" />
          {unreadCount > 0 && (
            <span
              data-testid="unread-dot"
              className="absolute top-2 right-2 min-w-[10px] h-2.5 px-1 bg-red-600 rounded-full border-2 border-white"
              aria-label={`${unreadCount} unread messages`}
            />
          )}
        </button>

        <button
          type="button"
          onClick={onOpenProfileModal}
          aria-label={`Open profile for ${user.username}`}
          className="flex items-center gap-2.5 min-h-[44px] pr-2 rounded-full hover:bg-gray-100 transition cursor-pointer min-w-0"
        >
          {user.photoURL ? (
            <img
              src={user.photoURL}
              alt={user.username}
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-full object-cover border border-gray-300 shrink-0"
            />
          ) : (
            <div className="w-9 h-9 rounded-full bg-blue-600 text-white font-semibold flex items-center justify-center text-sm shrink-0">
              {user.username.slice(0, 1).toUpperCase()}
            </div>
          )}
          <span className="font-semibold text-gray-900 text-sm truncate max-w-[140px] sm:max-w-[200px]">
            {user.username}
          </span>
        </button>

        <button
          type="button"
          onClick={onGoHome}
          className="text-xs font-bold uppercase tracking-widest text-gray-500 hover:text-gray-900 whitespace-nowrap shrink-0 pl-2 border-l border-gray-200 cursor-pointer"
        >
          business
        </button>
      </div>

      <button
        type="button"
        onClick={onOpenSearchModal}
        aria-label="Search products"
        className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full text-gray-600 hover:text-gray-950 hover:bg-gray-100 transition cursor-pointer shrink-0"
      >
        <Search className="w-5 h-5" />
      </button>
    </header>
  );
}
