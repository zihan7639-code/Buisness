import { useEffect, useRef, useState } from 'react';
import { SUBSCRIPTION_CHANNEL_URL } from '../utils/marketplaceLogic';

interface SubscriptionGateProps {
  onUnlocked: () => void;
}

export function SubscriptionGate({ onUnlocked }: SubscriptionGateProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [step, setStep] = useState<'init' | 'subscribe'>('init');
  const [verifying, setVerifying] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setStep('subscribe');
    }, 1200);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const cols = Math.max(1, Math.floor(canvas.width / 18));
    const drops = Array<number>(cols).fill(1);
    const chars = '01100';

    const interval = window.setInterval(() => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.06)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#00ff41';
      ctx.font = '14px "Share Tech Mono", monospace';

      for (let i = 0; i < drops.length; i++) {
        const ch = chars[Math.floor(Math.random() * chars.length)];
        ctx.fillText(ch, i * 18, drops[i] * 18);
        if (drops[i] * 18 > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
    }, 55);

    return () => {
      window.clearInterval(interval);
      window.removeEventListener('resize', resize);
    };
  }, []);

  const handleSubscribeClick = () => {
    if (verifying) return;
    setVerifying(true);
    window.setTimeout(() => {
      onUnlocked();
    }, 1600);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black p-4 select-none"
      data-testid="subscription-gate"
    >
      <canvas ref={canvasRef} className="fixed inset-0 opacity-15 pointer-events-none" />
      <div className="fixed inset-0 scanline-overlay pointer-events-none" />

      <div className="relative z-10 w-full max-w-[440px] bg-black/92 border border-[#00aa2a] shadow-[0_0_40px_rgba(0,255,65,0.25)] px-6 py-8 font-cyber-mono text-[#00ff41]">
        {step === 'init' ? (
          <div className="text-center">
            <div className="mb-4">
              <span className="text-3xl block mb-2 animate-pulse" aria-hidden="true">
                ⬡
              </span>
              <h1 className="font-cyber text-lg font-black tracking-widest text-[#00ff41]">
                SYSTEM INIT
              </h1>
              <p className="text-xs text-green-400/80 mt-1">Verifying Access Gate...</p>
            </div>
            <div className="w-full h-1 bg-[#00ff41] animate-pulse" />
          </div>
        ) : (
          <div className="text-center">
            <div className="mb-4">
              <span
                className="text-3xl block mb-2 text-[#ff003c] drop-shadow-[0_0_8px_#ff003c]"
                aria-hidden="true"
              >
                ⚠
              </span>
              <h1 className="font-cyber text-lg font-black tracking-widest text-[#ff003c] drop-shadow-[0_0_10px_rgba(255,0,60,0.6)]">
                SUB TO ULTRA
              </h1>
              <p className="text-xs text-red-400/90 mt-1.5">
                Subscription Required for Access
              </p>
            </div>

            <hr className="border-red-900/50 my-4" />

            <a
              href={SUBSCRIPTION_CHANNEL_URL}
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleSubscribeClick}
              className={`block w-full py-3.5 px-4 mt-4 border border-[#ff003c] text-[#ff003c] font-cyber font-bold text-sm tracking-widest shadow-[0_0_15px_rgba(255,0,60,0.3)] transition-all hover:bg-[#ff003c]/10 hover:shadow-[0_0_25px_rgba(255,0,60,0.6)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#ff003c] ${
                verifying ? 'opacity-60 pointer-events-none' : ''
              }`}
            >
              {verifying ? (
                '[ CHECKING... ]'
              ) : (
                <>
                  [ SUBSCRIBE TO UNLOCK ]<span className="animate-ping ml-1">_</span>
                </>
              )}
            </a>

            <p className="mt-3 text-[11px] text-zinc-400">
              Opens Ultra-Gaming-2.O-Official on YouTube to unlock access
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
