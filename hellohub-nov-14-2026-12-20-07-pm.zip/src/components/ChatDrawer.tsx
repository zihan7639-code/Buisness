import { Search, X } from 'lucide-react';
import type { ConversationSummary, PublicUser } from '../types';
import { formatShortTime, getMessagePreviewText } from '../utils/marketplaceLogic';

interface ChatDrawerProps {
  open: boolean;
  summaries: ConversationSummary[];
  searchQuery: string;
  onSearchChange: (value: string) => void;
  onSelectPeer: (peer: PublicUser) => void;
  onClose: () => void;
}

export function ChatDrawer({
  open,
  summaries,
  searchQuery,
  onSearchChange,
  onSelectPeer,
  onClose,
}: ChatDrawerProps) {
  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Messages drawer"
      className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex"
    >
      <div className="bg-white text-gray-900 w-80 max-w-[85vw] h-full shadow-2xl flex flex-col p-4 border-r border-gray-200">
        <div className="flex justify-between items-center pb-3 border-b border-gray-200 mb-4">
          <h2 className="text-xl font-bold text-gray-900">Messages</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close messages drawer"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-full text-gray-500 hover:text-gray-900 hover:bg-gray-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="relative mb-4">
          <Search className="w-4 h-4 absolute left-3 top-3 text-gray-400 pointer-events-none" />
          <label htmlFor="search-chat-account" className="sr-only">
            Search conversation
          </label>
          <input
            id="search-chat-account"
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search conversation..."
            className="w-full pl-9 pr-3 py-2.5 bg-gray-100 border border-gray-200 rounded-lg text-sm text-gray-900 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div
          className="flex-1 overflow-y-auto space-y-1.5"
          data-testid="recent-chats-list"
        >
          {summaries.length === 0 ? (
            <p className="text-xs text-gray-500 text-center py-8">
              {searchQuery.trim()
                ? 'No matching conversations.'
                : 'No conversations yet. Open any product and tap Chat.'}
            </p>
          ) : (
            summaries.map(({ peer, lastMessage, unreadCount }) => (
              <button
                key={peer.uid}
                type="button"
                onClick={() => onSelectPeer(peer)}
                className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-100 transition text-left cursor-pointer min-h-[58px]"
              >
                {peer.photoURL ? (
                  <img
                    src={peer.photoURL}
                    alt={peer.username}
                    referrerPolicy="no-referrer"
                    className="w-11 h-11 rounded-full object-cover border border-gray-200 shrink-0"
                  />
                ) : (
                  <div className="w-11 h-11 rounded-full bg-blue-600 text-white font-semibold flex items-center justify-center text-sm shrink-0">
                    {peer.username.slice(0, 1).toUpperCase()}
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-sm text-gray-900 truncate">
                      {peer.username}
                    </span>
                    <span className="text-[11px] text-gray-400 tabular-nums shrink-0">
                      {formatShortTime(lastMessage.timestamp)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2 mt-0.5">
                    <p
                      className={`text-xs truncate ${
                        unreadCount > 0 ? 'font-semibold text-gray-900' : 'text-gray-500'
                      }`}
                    >
                      {getMessagePreviewText(lastMessage)}
                    </p>
                    {unreadCount > 0 && (
                      <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-blue-600 text-white text-[11px] font-bold flex items-center justify-center tabular-nums shrink-0">
                        {unreadCount}
                      </span>
                    )}
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      <button
        type="button"
        aria-label="Dismiss messages drawer"
        onClick={onClose}
        className="flex-1 cursor-default"
      />
    </div>
  );
}
