import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { ArrowLeft, MoreVertical, Plus, X, ZoomIn } from 'lucide-react';
import type { ChatMediaItem, ChatMessage, PublicUser, ZoomMedia } from '../types';
import { formatShortTime, normalizeMessageMedia } from '../utils/marketplaceLogic';
import { processChatMediaFiles } from '../utils/mediaCompression';

interface StagedAttachment extends ChatMediaItem {
  id: string;
}

interface DirectChatViewProps {
  currentUser: PublicUser;
  recipient: PublicUser;
  messages: ChatMessage[];
  isBlocked: boolean;
  onBack: () => void;
  onSendMessage: (payload: {
    text: string;
    mediaItems: ChatMediaItem[];
  }) => Promise<boolean>;
  onBlockUser: (targetUserId: string) => void;
  onUnblockUser: (targetUserId: string) => void;
  onZoomPhoto: (media: ZoomMedia) => void;
}

export function DirectChatView({
  currentUser,
  recipient,
  messages,
  isBlocked,
  onBack,
  onSendMessage,
  onBlockUser,
  onUnblockUser,
  onZoomPhoto,
}: DirectChatViewProps) {
  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<StagedAttachment[]>([]);
  const [preparingMedia, setPreparingMedia] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const endRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const handleMediaSelect = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setPreparingMedia(true);
    try {
      const processed = await processChatMediaFiles(files);
      if (processed.length > 0) {
        setAttachments((prev) => [
          ...prev,
          ...processed.map((item, idx) => ({
            ...item,
            id: `att_${Date.now()}_${idx}_${Math.random().toString(36).slice(2, 6)}`,
          })),
        ]);
      }
    } finally {
      setPreparingMedia(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((item) => item.id !== id));
  };

  const clearAllAttachments = () => {
    setAttachments([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (preparingMedia) return;
    const cleanText = text.trim();
    if (!cleanText && attachments.length === 0) return;

    const mediaToSend: ChatMediaItem[] = attachments.map(({ src, mediaType }) => ({
      src,
      mediaType,
    }));

    // Clear composer immediately so sending feels instantaneous
    setText('');
    setAttachments([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    void onSendMessage({
      text: cleanText,
      mediaItems: mediaToSend,
    });
  };

  return (
    <div className="h-[calc(100vh-65px)] bg-[#f3f4f6] flex flex-col overflow-hidden">
      <div className="flex-1 min-h-0 flex flex-col bg-white text-gray-900 max-w-2xl mx-auto w-full border-x border-gray-200 shadow-xs">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 bg-white shrink-0 z-30">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={onBack}
              aria-label="Back to dashboard"
              className="min-w-[40px] min-h-[40px] flex items-center justify-center hover:bg-gray-100 rounded-full cursor-pointer shrink-0"
            >
              <ArrowLeft className="w-5 h-5 text-gray-700" />
            </button>

            {recipient.photoURL ? (
              <img
                src={recipient.photoURL}
                alt={recipient.username}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full object-cover border border-gray-300 shrink-0"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-blue-600 text-white font-semibold flex items-center justify-center text-sm shrink-0">
                {recipient.username.slice(0, 1).toUpperCase()}
              </div>
            )}

            <h3 className="font-bold text-gray-900 text-base truncate">
              {recipient.username}
            </h3>
          </div>

          <div className="relative">
            <button
              type="button"
              onClick={() => setMenuOpen((prev) => !prev)}
              aria-label="Chat options"
              aria-expanded={menuOpen}
              className="min-w-[40px] min-h-[40px] flex items-center justify-center text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full cursor-pointer"
            >
              <MoreVertical className="w-5 h-5" />
            </button>

            {menuOpen && (
              <div className="absolute right-0 top-11 bg-white border border-gray-200 shadow-lg rounded-lg py-1 w-32 z-50">
                {isBlocked ? (
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onUnblockUser(recipient.uid);
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 font-medium cursor-pointer"
                  >
                    Unblock
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onBlockUser(recipient.uid);
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 font-medium cursor-pointer"
                  >
                    Block
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        <div
          className="flex-1 p-4 space-y-3 overflow-y-auto bg-gray-50 min-h-[380px]"
          data-testid="chat-messages"
        >
          {messages.length === 0 ? (
            <div className="h-full flex items-center justify-center py-16">
              <p className="text-xs text-gray-500 text-center">
                Say hello to {recipient.username}. Messages and photos appear live for both
                accounts.
              </p>
            </div>
          ) : (
            messages.map((msg) => {
              const isMe = msg.senderId === currentUser.uid;
              const items = normalizeMessageMedia(msg);
              const imageGallery = items
                .filter((item) => item.mediaType !== 'video')
                .map((item) => item.src);
              const isMultiGrid = items.length > 1;

              return (
                <div
                  key={msg.id}
                  className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[78%] rounded-2xl px-3.5 py-2.5 text-sm shadow-2xs ${
                      isMe
                        ? 'bg-[#0088ff] text-white rounded-br-xs'
                        : 'bg-white border border-gray-200 text-gray-900 rounded-bl-xs'
                    }`}
                  >
                    {items.length > 0 && (
                      <div
                        className={
                          isMultiGrid
                            ? 'grid grid-cols-2 gap-1.5 mb-1.5'
                            : 'space-y-1.5 mb-1.5'
                        }
                      >
                        {items.map((item, idx) => {
                          if (item.mediaType === 'video') {
                            return (
                              <video
                                key={`${msg.id}_vid_${idx}`}
                                src={item.src}
                                controls
                                className={
                                  isMultiGrid
                                    ? 'w-full h-32 rounded-lg object-cover bg-black col-span-2'
                                    : 'max-w-full max-h-60 rounded-lg'
                                }
                              />
                            );
                          }

                          const galleryIndex = imageGallery.indexOf(item.src);
                          return (
                            <button
                              key={`${msg.id}_img_${idx}`}
                              type="button"
                              onClick={() =>
                                onZoomPhoto({
                                  src: item.src,
                                  alt: isMe
                                    ? `Photo sent to ${recipient.username}`
                                    : `Photo from ${recipient.username}`,
                                  subtitle: formatShortTime(msg.timestamp),
                                  gallery:
                                    imageGallery.length > 1 ? imageGallery : undefined,
                                  initialIndex: galleryIndex >= 0 ? galleryIndex : 0,
                                })
                              }
                              aria-label={
                                items.length > 1
                                  ? `Zoom in on chat photo ${idx + 1}`
                                  : 'Zoom in on chat photo'
                              }
                              className="relative group block rounded-lg overflow-hidden cursor-zoom-in w-full"
                            >
                              <img
                                src={item.src}
                                alt={`Chat attachment ${idx + 1}`}
                                referrerPolicy="no-referrer"
                                className={
                                  isMultiGrid
                                    ? 'w-full h-28 sm:h-32 object-cover rounded-lg'
                                    : 'max-w-[240px] max-h-60 object-cover rounded-lg'
                                }
                              />
                              <span className="absolute bottom-1.5 right-1.5 w-6 h-6 rounded-full bg-black/65 text-white flex items-center justify-center opacity-90 group-hover:scale-105 transition">
                                <ZoomIn className="w-3 h-3" />
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {msg.text && (
                      <p className="leading-relaxed whitespace-pre-wrap break-words">
                        {msg.text}
                      </p>
                    )}

                    <p
                      className={`text-[10px] mt-1 text-right tabular-nums ${
                        isMe ? 'text-blue-100' : 'text-gray-400'
                      }`}
                    >
                      {formatShortTime(msg.timestamp)}
                    </p>
                  </div>
                </div>
              );
            })
          )}
          <div ref={endRef} />
        </div>

        {(attachments.length > 0 || preparingMedia) && (
          <div
            className="px-4 py-2.5 bg-gray-100 border-t border-gray-200 space-y-2"
            data-testid="chat-attachment-tray"
          >
            <div className="flex items-center justify-between text-xs text-gray-600">
              <span className="font-semibold tabular-nums">
                {preparingMedia
                  ? 'Preparing photos...'
                  : `${attachments.length} ${
                      attachments.length === 1 ? 'item' : 'items'
                    } ready to send`}
              </span>
              {attachments.length > 1 && (
                <button
                  type="button"
                  onClick={clearAllAttachments}
                  className="text-red-600 hover:underline font-medium cursor-pointer"
                >
                  Clear all
                </button>
              )}
            </div>

            {attachments.length > 0 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {attachments.map((item, idx) => (
                  <div
                    key={item.id}
                    className="relative w-14 h-14 rounded-lg overflow-hidden border border-gray-300 bg-white shrink-0"
                  >
                    {item.mediaType === 'video' ? (
                      <video
                        src={item.src}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <img
                        src={item.src}
                        alt={`Selected attachment ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                    )}
                    <button
                      type="button"
                      onClick={() => removeAttachment(item.id)}
                      aria-label={`Remove attachment ${idx + 1}`}
                      className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-black/75 text-white flex items-center justify-center hover:bg-red-600 transition cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {isBlocked ? (
          <div className="p-3.5 border-t border-gray-200 bg-gray-100 flex items-center justify-between px-5">
            <span className="text-xs text-gray-600 font-medium">
              You have blocked this user.
            </span>
            <button
              type="button"
              onClick={() => onUnblockUser(recipient.uid)}
              className="text-blue-600 hover:underline font-bold text-sm cursor-pointer"
            >
              Unblock
            </button>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="p-3 border-t border-gray-200 bg-white flex items-center gap-2 sticky bottom-0"
          >
            <label
              htmlFor="chat-media-input"
              aria-label="Attach photos or videos"
              title="Select one or multiple photos"
              className="min-w-[44px] min-h-[44px] flex items-center justify-center text-gray-600 hover:text-[#0088ff] cursor-pointer rounded-full hover:bg-gray-100 transition shrink-0"
            >
              <Plus className="w-5 h-5" />
            </label>
            <input
              ref={fileInputRef}
              id="chat-media-input"
              type="file"
              accept="image/*,video/*"
              multiple
              onChange={handleMediaSelect}
              className="sr-only"
            />

            <label htmlFor="chat-input-text" className="sr-only">
              Type a message
            </label>
            <input
              id="chat-input-text"
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 bg-gray-100 border border-gray-200 rounded-full px-4 py-2.5 text-sm focus:outline-none focus:border-[#0088ff] text-gray-900"
            />

            {/* imo-style circular blue paper-plane send icon button */}
            <button
              type="submit"
              disabled={preparingMedia}
              aria-label="Send message"
              title="Send"
              className="w-11 h-11 rounded-full bg-[#0088ff] hover:bg-[#0073e6] active:scale-95 disabled:opacity-60 text-white flex items-center justify-center shadow-sm transition cursor-pointer shrink-0"
            >
              <svg
                viewBox="0 0 24 24"
                fill="currentColor"
                className="w-5 h-5 translate-x-[1px]"
                aria-hidden="true"
              >
                <path d="M3.478 2.405a.75.75 0 0 0-.926.94l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.405Z" />
              </svg>
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
