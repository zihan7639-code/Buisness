import { useEffect, useRef, useState, type MouseEvent, type WheelEvent } from 'react';
import { ChevronLeft, ChevronRight, RotateCcw, X, ZoomIn, ZoomOut } from 'lucide-react';
import { clampZoomScale } from '../utils/marketplaceLogic';
import type { ZoomMedia } from '../types';

interface PhotoZoomModalProps {
  media: ZoomMedia | null;
  onClose: () => void;
}

export function PhotoZoomModal({ media, onClose }: PhotoZoomModalProps) {
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [activeIndex, setActiveIndex] = useState(0);
  const [dragging, setDragging] = useState(false);
  const dragStartRef = useRef<{ x: number; y: number; origX: number; origY: number } | null>(
    null
  );

  const gallery = media?.gallery && media.gallery.length > 1 ? media.gallery : null;

  useEffect(() => {
    setScale(1);
    setOffset({ x: 0, y: 0 });
    setActiveIndex(media?.initialIndex ?? 0);
  }, [media?.src, media?.initialIndex]);

  useEffect(() => {
    if (!media) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === '+' || e.key === '=') setScale((s) => clampZoomScale(s + 0.5));
      if (e.key === '-') {
        setScale((s) => {
          const next = clampZoomScale(s - 0.5);
          if (next === 1) setOffset({ x: 0, y: 0 });
          return next;
        });
      }
      if (gallery && e.key === 'ArrowRight') {
        setScale(1);
        setOffset({ x: 0, y: 0 });
        setActiveIndex((idx) => (idx + 1) % gallery.length);
      }
      if (gallery && e.key === 'ArrowLeft') {
        setScale(1);
        setOffset({ x: 0, y: 0 });
        setActiveIndex((idx) => (idx - 1 + gallery.length) % gallery.length);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [media, gallery, onClose]);

  if (!media) return null;

  const activeSrc = gallery ? gallery[activeIndex] ?? media.src : media.src;

  const zoomIn = () => setScale((s) => clampZoomScale(s + 0.5));
  const zoomOut = () => {
    setScale((s) => {
      const next = clampZoomScale(s - 0.5);
      if (next === 1) setOffset({ x: 0, y: 0 });
      return next;
    });
  };
  const resetZoom = () => {
    setScale(1);
    setOffset({ x: 0, y: 0 });
  };

  const stepPhoto = (delta: number) => {
    if (!gallery) return;
    resetZoom();
    setActiveIndex((idx) => (idx + delta + gallery.length) % gallery.length);
  };

  const handleWheel = (e: WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? 0.35 : -0.35;
    setScale((s) => {
      const next = clampZoomScale(s + delta);
      if (next === 1) setOffset({ x: 0, y: 0 });
      return next;
    });
  };

  const handleMouseDown = (e: MouseEvent<HTMLDivElement>) => {
    if (scale <= 1) return;
    setDragging(true);
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      origX: offset.x,
      origY: offset.y,
    };
  };

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!dragging || !dragStartRef.current) return;
    setOffset({
      x: dragStartRef.current.origX + (e.clientX - dragStartRef.current.x),
      y: dragStartRef.current.origY + (e.clientY - dragStartRef.current.y),
    });
  };

  const handleMouseUp = () => {
    setDragging(false);
    dragStartRef.current = null;
  };

  const handleDoubleClick = () => {
    if (scale > 1) {
      resetZoom();
    } else {
      setScale(2.5);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Photo zoom viewer"
      className="fixed inset-0 z-50 bg-black flex flex-col select-none"
    >
      <div className="relative z-10 flex items-center justify-between px-4 py-3 bg-zinc-950 border-b border-white/10 text-white">
        <div className="min-w-0">
          <p className="text-sm font-semibold truncate">
            {media.alt}
            {gallery ? ` (${activeIndex + 1} / ${gallery.length})` : ''}
          </p>
          {media.subtitle && (
            <p className="text-xs text-zinc-400 truncate">{media.subtitle}</p>
          )}
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={zoomOut}
            disabled={scale <= 1}
            aria-label="Zoom out"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg bg-white/10 hover:bg-white/20 disabled:opacity-40 transition cursor-pointer"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono tabular-nums px-2 min-w-[52px] text-center">
            {Math.round(scale * 100)}%
          </span>
          <button
            type="button"
            onClick={zoomIn}
            disabled={scale >= 4}
            aria-label="Zoom in"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg bg-white/10 hover:bg-white/20 disabled:opacity-40 transition cursor-pointer"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={resetZoom}
            aria-label="Reset zoom"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close photo zoom"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg bg-white/15 hover:bg-red-600 transition cursor-pointer ml-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onDoubleClick={handleDoubleClick}
        className={`relative flex-1 flex items-center justify-center overflow-hidden p-4 ${
          scale > 1 ? (dragging ? 'cursor-grabbing' : 'cursor-grab') : 'cursor-zoom-in'
        }`}
      >
        {gallery && (
          <>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                stepPhoto(-1);
              }}
              aria-label="Previous photo"
              className="absolute left-3 z-20 w-10 h-10 rounded-full bg-black/70 hover:bg-black text-white border border-white/20 flex items-center justify-center cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                stepPhoto(1);
              }}
              aria-label="Next photo"
              className="absolute right-3 z-20 w-10 h-10 rounded-full bg-black/70 hover:bg-black text-white border border-white/20 flex items-center justify-center cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        <img
          src={activeSrc}
          alt={media.alt}
          referrerPolicy="no-referrer"
          draggable={false}
          style={{
            transform: `translate3d(${offset.x}px, ${offset.y}px, 0) scale(${scale})`,
            transition: dragging ? 'none' : 'transform 160ms cubic-bezier(0.16, 1, 0.3, 1)',
          }}
          className="max-w-full max-h-[76vh] object-contain rounded-lg shadow-2xl"
        />
      </div>

      <div className="relative z-10 bg-zinc-950 border-t border-white/10 text-center py-2.5 text-xs text-zinc-400">
        Tap + / - , scroll, or double-click photo to zoom (100%–400%)
      </div>
    </div>
  );
}
