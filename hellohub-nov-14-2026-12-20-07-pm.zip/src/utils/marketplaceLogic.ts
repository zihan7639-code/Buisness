import type {
  ChatMediaItem,
  ChatMessage,
  ConversationSummary,
  Product,
  PublicUser,
} from '../types';

export interface ValidationResult {
  valid: boolean;
  error?: string;
  toastError?: string;
}

export const SUBSCRIPTION_CHANNEL_URL =
  'https://www.youtube.com/@Ultra-Gaming-2.O-Official';

export const CURRENCY_OPTIONS = ['৳ TK', '$ USD', '€ EUR', '£ GBP', '₹ INR'] as const;

export function getThreadKey(userIdA: string, userIdB: string): string {
  return [userIdA, userIdB].sort().join('__');
}

export function validateAuthInput(params: {
  username: string;
  password: string;
  hasAvatar: boolean;
}): ValidationResult {
  const username = params.username.trim();
  if (!params.hasAvatar) {
    return { valid: false, toastError: 'Please put your profile picture' };
  }
  if (username.length < 2 || username.length > 16) {
    return { valid: false, error: 'Username must be 2 to 16 characters.' };
  }
  if (params.password.length < 2 || params.password.length > 16) {
    return { valid: false, error: 'Password must be 2 to 16 characters.' };
  }
  return { valid: true };
}

export function validateProductInput(params: {
  name: string;
  price: string;
  description: string;
}): ValidationResult {
  const name = params.name.trim();
  const priceStr = params.price.trim();
  const desc = params.description.trim();

  if (name.length < 2 || name.length > 8) {
    return { valid: false, error: 'Product name must be 2 to 8 characters.' };
  }
  const numericPrice = Number(priceStr);
  if (!priceStr || Number.isNaN(numericPrice) || numericPrice < 0) {
    return { valid: false, error: 'Please specify a valid price.' };
  }
  if (desc.length > 0 && (desc.length < 10 || desc.length > 500)) {
    return {
      valid: false,
      error: 'Description must be 10 to 500 characters if provided.',
    };
  }
  return { valid: true };
}

export function validatePasswordChange(params: {
  oldPassword: string;
  newPassword: string;
  confirmPassword: string;
}): ValidationResult {
  if (!params.oldPassword) {
    return { valid: false, error: 'Please enter your current password.' };
  }
  if (params.newPassword.length < 2 || params.newPassword.length > 16) {
    return { valid: false, error: 'New password must be 2 to 16 characters.' };
  }
  if (params.newPassword !== params.confirmPassword) {
    return { valid: false, error: 'New passwords do not match!' };
  }
  return { valid: true };
}

export function filterProducts(products: Product[], query: string): Product[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  return products.filter(
    (item) =>
      item.name.toLowerCase().includes(q) ||
      item.username.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q)
  );
}

export function buildConversationSummaries(params: {
  currentUserId: string;
  users: PublicUser[];
  messages: ChatMessage[];
  searchQuery?: string;
}): ConversationSummary[] {
  const { currentUserId, users, messages, searchQuery = '' } = params;
  if (!currentUserId) return [];

  const userMap = new Map<string, PublicUser>();
  for (const u of users) {
    userMap.set(u.uid, u);
  }

  const byPeer = new Map<string, { lastMessage: ChatMessage; unreadCount: number }>();

  for (const msg of messages) {
    if (msg.senderId !== currentUserId && msg.recipientId !== currentUserId) {
      continue;
    }
    const peerId = msg.senderId === currentUserId ? msg.recipientId : msg.senderId;
    if (!peerId || peerId === currentUserId) continue;

    const existing = byPeer.get(peerId);
    const isUnread =
      msg.recipientId === currentUserId &&
      (!Array.isArray(msg.readBy) || !msg.readBy.includes(currentUserId));

    if (!existing) {
      byPeer.set(peerId, {
        lastMessage: msg,
        unreadCount: isUnread ? 1 : 0,
      });
    } else {
      const nextUnread = existing.unreadCount + (isUnread ? 1 : 0);
      const isNewer =
        new Date(msg.timestamp).getTime() >= new Date(existing.lastMessage.timestamp).getTime();
      byPeer.set(peerId, {
        lastMessage: isNewer ? msg : existing.lastMessage,
        unreadCount: nextUnread,
      });
    }
  }

  const q = searchQuery.trim().toLowerCase();
  const summaries: ConversationSummary[] = [];

  for (const [peerId, entry] of byPeer.entries()) {
    const peer = userMap.get(peerId) ?? {
      uid: peerId,
      username: 'User',
      photoURL: '',
    };
    if (q && !peer.username.toLowerCase().includes(q)) {
      continue;
    }
    summaries.push({
      peer,
      lastMessage: entry.lastMessage,
      unreadCount: entry.unreadCount,
    });
  }

  summaries.sort(
    (a, b) =>
      new Date(b.lastMessage.timestamp).getTime() -
      new Date(a.lastMessage.timestamp).getTime()
  );

  return summaries;
}

export function countTotalUnread(summaries: ConversationSummary[]): number {
  return summaries.reduce((sum, item) => sum + item.unreadCount, 0);
}

export function clampZoomScale(scale: number): number {
  if (!Number.isFinite(scale)) return 1;
  return Math.min(4, Math.max(1, Math.round(scale * 100) / 100));
}

export function formatShortTime(isoTimestamp: string): string {
  const date = new Date(isoTimestamp);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function normalizeMessageMedia(msg: ChatMessage): ChatMediaItem[] {
  if (Array.isArray(msg.mediaItems) && msg.mediaItems.length > 0) {
    return msg.mediaItems.filter((item) => Boolean(item && item.src));
  }
  if (msg.media) {
    const type: 'image' | 'video' =
      msg.mediaType === 'video' || msg.media.startsWith('data:video')
        ? 'video'
        : 'image';
    return [{ src: msg.media, mediaType: type }];
  }
  return [];
}

export function getMessagePreviewText(msg: ChatMessage): string {
  if (msg.text && msg.text.trim()) return msg.text.trim();
  const items = normalizeMessageMedia(msg);
  if (items.length === 0) return '';
  if (items.length === 1) {
    return items[0].mediaType === 'video' ? 'Video' : 'Photo';
  }
  const allImages = items.every((i) => i.mediaType === 'image');
  if (allImages) return `${items.length} Photos`;
  const allVideos = items.every((i) => i.mediaType === 'video');
  if (allVideos) return `${items.length} Videos`;
  return `${items.length} Attachments`;
}
