import test from 'node:test';
import assert from 'node:assert/strict';
import {
  SUBSCRIPTION_CHANNEL_URL,
  buildConversationSummaries,
  clampZoomScale,
  countTotalUnread,
  filterProducts,
  getMessagePreviewText,
  getThreadKey,
  normalizeMessageMedia,
  validateAuthInput,
  validatePasswordChange,
  validateProductInput,
} from './marketplaceLogic';
import type { ChatMessage, Product, PublicUser } from '../types';

test('SUBSCRIPTION_CHANNEL_URL points to Ultra-Gaming-2.O-Official', () => {
  assert.equal(
    SUBSCRIPTION_CHANNEL_URL,
    'https://www.youtube.com/@Ultra-Gaming-2.O-Official'
  );
});

test('getThreadKey is symmetric across user order', () => {
  assert.equal(getThreadKey('user_b', 'user_a'), 'user_a__user_b');
  assert.equal(getThreadKey('user_a', 'user_b'), 'user_a__user_b');
});

test('validateAuthInput enforces avatar, username, and password lengths', () => {
  assert.deepEqual(
    validateAuthInput({ username: 'Alex', password: 'pw', hasAvatar: false }),
    { valid: false, toastError: 'Please put your profile picture' }
  );
  assert.deepEqual(
    validateAuthInput({ username: 'A', password: 'secret', hasAvatar: true }),
    { valid: false, error: 'Username must be 2 to 16 characters.' }
  );
  assert.deepEqual(
    validateAuthInput({ username: 'Alex', password: '1', hasAvatar: true }),
    { valid: false, error: 'Password must be 2 to 16 characters.' }
  );
  assert.deepEqual(
    validateAuthInput({ username: 'Alex', password: 'secret', hasAvatar: true }),
    { valid: true }
  );
});

test('validateProductInput enforces 2-8 char name, valid price, and optional 10-500 char description', () => {
  assert.equal(
    validateProductInput({ name: 'X', price: '100', description: '' }).valid,
    false
  );
  assert.equal(
    validateProductInput({ name: 'TooLongName', price: '100', description: '' }).valid,
    false
  );
  assert.equal(
    validateProductInput({ name: 'Phone', price: '', description: '' }).valid,
    false
  );
  assert.equal(
    validateProductInput({ name: 'Phone', price: '500', description: 'Short' }).valid,
    false
  );
  assert.equal(
    validateProductInput({
      name: 'Phone',
      price: '500',
      description: 'Mint condition flagship phone with box.',
    }).valid,
    true
  );
});

test('validatePasswordChange validates new password match and length', () => {
  assert.equal(
    validatePasswordChange({ oldPassword: 'old', newPassword: '1', confirmPassword: '1' })
      .valid,
    false
  );
  assert.equal(
    validatePasswordChange({
      oldPassword: 'old',
      newPassword: 'newpass',
      confirmPassword: 'other',
    }).valid,
    false
  );
  assert.equal(
    validatePasswordChange({
      oldPassword: 'old',
      newPassword: 'newpass',
      confirmPassword: 'newpass',
    }).valid,
    true
  );
});

test('buildConversationSummaries builds sorted accounts for the 3-line menu drawer with unread counts', () => {
  const users: PublicUser[] = [
    { uid: 'u1', username: 'Alice', photoURL: '/a.jpg' },
    { uid: 'u2', username: 'Bob', photoURL: '/b.jpg' },
    { uid: 'u3', username: 'Charlie', photoURL: '/c.jpg' },
  ];

  const messages: ChatMessage[] = [
    {
      id: 'm1',
      threadKey: 'u1__u2',
      senderId: 'u1',
      recipientId: 'u2',
      text: 'Hi Bob',
      media: '',
      timestamp: '2026-11-13T10:00:00.000Z',
      readBy: ['u1', 'u2'],
    },
    {
      id: 'm2',
      threadKey: 'u1__u3',
      senderId: 'u3',
      recipientId: 'u1',
      text: 'Is the watch still available?',
      media: '',
      timestamp: '2026-11-13T10:05:00.000Z',
      readBy: ['u3'],
    },
    {
      id: 'm3',
      threadKey: 'u1__u3',
      senderId: 'u3',
      recipientId: 'u1',
      text: '',
      media: 'data:image/png;base64,abc',
      mediaType: 'image',
      timestamp: '2026-11-13T10:06:00.000Z',
      readBy: ['u3'],
    },
  ];

  const summaries = buildConversationSummaries({
    currentUserId: 'u1',
    users,
    messages,
  });

  assert.equal(summaries.length, 2);
  assert.equal(summaries[0].peer.uid, 'u3');
  assert.equal(summaries[0].unreadCount, 2);
  assert.equal(getMessagePreviewText(summaries[0].lastMessage), 'Photo');
  assert.equal(summaries[1].peer.uid, 'u2');
  assert.equal(summaries[1].unreadCount, 0);
  assert.equal(countTotalUnread(summaries), 2);

  const filtered = buildConversationSummaries({
    currentUserId: 'u1',
    users,
    messages,
    searchQuery: 'bob',
  });
  assert.equal(filtered.length, 1);
  assert.equal(filtered[0].peer.username, 'Bob');
});

test('filterProducts matches by product name or seller', () => {
  const products: Product[] = [
    {
      id: 'p1',
      name: 'Camera',
      price: '450',
      currency: '$ USD',
      description: 'Mirrorless digital camera',
      photoURL: '/cam.jpg',
      userId: 'u1',
      username: 'Alex',
      userPhoto: '/alex.jpg',
      createdAt: '2026-11-13T10:00:00.000Z',
    },
    {
      id: 'p2',
      name: 'Watch',
      price: '220',
      currency: '$ USD',
      description: 'Brushed steel timepiece',
      photoURL: '/watch.jpg',
      userId: 'u2',
      username: 'Maya',
      userPhoto: '/maya.jpg',
      createdAt: '2026-11-13T10:00:00.000Z',
    },
  ];

  assert.equal(filterProducts(products, 'cam').length, 1);
  assert.equal(filterProducts(products, 'maya').length, 1);
  assert.equal(filterProducts(products, '').length, 0);
});

test('clampZoomScale keeps zoom within 1x to 4x', () => {
  assert.equal(clampZoomScale(0.5), 1);
  assert.equal(clampZoomScale(2.345), 2.35);
  assert.equal(clampZoomScale(9), 4);
  assert.equal(clampZoomScale(Number.NaN), 1);
});

test('normalizeMessageMedia and getMessagePreviewText support multi-photo messages', () => {
  const multiMsg: ChatMessage = {
    id: 'm_multi',
    threadKey: 'u1__u2',
    senderId: 'u1',
    recipientId: 'u2',
    text: '',
    media: 'data:image/jpeg;base64,one',
    mediaType: 'image',
    mediaItems: [
      { src: 'data:image/jpeg;base64,one', mediaType: 'image' },
      { src: 'data:image/jpeg;base64,two', mediaType: 'image' },
      { src: 'data:image/jpeg;base64,three', mediaType: 'image' },
    ],
    timestamp: '2026-11-13T10:10:00.000Z',
    readBy: ['u1'],
  };

  assert.equal(normalizeMessageMedia(multiMsg).length, 3);
  assert.equal(getMessagePreviewText(multiMsg), '3 Photos');
});
