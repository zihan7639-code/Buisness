import type { ChatMediaItem } from '../types';

function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read file as data URL'));
      }
    };
    reader.onerror = () => reject(reader.error ?? new Error('File read error'));
    reader.readAsDataURL(file);
  });
}

async function compressImageFile(
  file: File,
  maxDimension = 1280,
  quality = 0.78
): Promise<string> {
  // Keep small images and GIFs untouched for maximum speed and animation preservation
  if (file.size <= 120 * 1024 || file.type === 'image/gif') {
    return readFileAsDataURL(file);
  }

  try {
    let width = 0;
    let height = 0;
    let drawSource: CanvasImageSource | null = null;
    let bitmapToClose: ImageBitmap | null = null;

    if (typeof createImageBitmap === 'function') {
      const bitmap = await createImageBitmap(file);
      width = bitmap.width;
      height = bitmap.height;
      drawSource = bitmap;
      bitmapToClose = bitmap;
    } else {
      const dataUrl = await readFileAsDataURL(file);
      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const el = new Image();
        el.onload = () => resolve(el);
        el.onerror = () => reject(new Error('Image decode failed'));
        el.src = dataUrl;
      });
      width = img.naturalWidth || img.width;
      height = img.naturalHeight || img.height;
      drawSource = img;
    }

    if (!drawSource || width <= 0 || height <= 0) {
      if (bitmapToClose) bitmapToClose.close();
      return readFileAsDataURL(file);
    }

    const scale = Math.min(1, maxDimension / Math.max(width, height));
    const targetWidth = Math.max(1, Math.round(width * scale));
    const targetHeight = Math.max(1, Math.round(height * scale));

    const canvas = document.createElement('canvas');
    canvas.width = targetWidth;
    canvas.height = targetHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      if (bitmapToClose) bitmapToClose.close();
      return readFileAsDataURL(file);
    }

    ctx.drawImage(drawSource, 0, 0, targetWidth, targetHeight);
    if (bitmapToClose) bitmapToClose.close();

    return canvas.toDataURL('image/jpeg', quality);
  } catch {
    return readFileAsDataURL(file);
  }
}

export async function processChatMediaFiles(
  fileList: FileList | File[]
): Promise<ChatMediaItem[]> {
  const files = Array.from(fileList);
  const results = await Promise.all(
    files.map(async (file): Promise<ChatMediaItem | null> => {
      if (file.type.startsWith('video/')) {
        const src = await readFileAsDataURL(file);
        return { src, mediaType: 'video' };
      }
      if (file.type.startsWith('image/')) {
        const src = await compressImageFile(file);
        return { src, mediaType: 'image' };
      }
      return null;
    })
  );

  return results.filter((item): item is ChatMediaItem => item !== null);
}
