export interface PublicUser {
  uid: string;
  username: string;
  photoURL: string;
  blockedUsers?: string[];
  createdAt?: string;
}

export interface Product {
  id: string;
  name: string;
  price: string;
  currency: string;
  description: string;
  photoURL: string;
  userId: string;
  username: string;
  userPhoto: string;
  createdAt: string;
}

export interface ChatMediaItem {
  src: string;
  mediaType: 'image' | 'video';
}

export interface ChatMessage {
  id: string;
  threadKey: string;
  senderId: string;
  recipientId: string;
  text: string;
  media: string;
  mediaType?: 'image' | 'video' | '';
  mediaItems?: ChatMediaItem[];
  timestamp: string;
  readBy: string[];
}

export interface ConversationSummary {
  peer: PublicUser;
  lastMessage: ChatMessage;
  unreadCount: number;
}

export interface ZoomMedia {
  src: string;
  alt: string;
  subtitle?: string;
  gallery?: string[];
  initialIndex?: number;
}
